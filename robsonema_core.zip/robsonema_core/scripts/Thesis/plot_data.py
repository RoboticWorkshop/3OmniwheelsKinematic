#!/usr/bin/env python
from numpy import *
from math import *
from numpy import linalg as LA
import matplotlib.pyplot as plt

def read_file(filename, var, tim):
	i = 0
	with open(filename) as fh:
		for line in fh:
			sp = line.split("\n")
			var.append(sp)
			tim.append(i*0.1)
			del var[i][1]
			i = i+1

def convert_data(data_file, var):
	for i in range(len(data_file)):
		var.append(float(data_file[i][0]))
	
file1 = "position_error.txt"
file2 = "position_error1.txt"

data = []
error  = []
data1 = []
error1 = []
ts = []
ts1 = []

read_file(file1, error, ts)
read_file(file2, error1, ts1)
convert_data(error,data)
convert_data(error1,data1)
#print data
#print len(error)
x=range(0,len(error))
#print x
plt.figure(0)
plt.plot(ts,data)
plt.ylabel("error norm value (m)")
plt.xlabel("t")
plt.figure(1)
plt.plot(ts1,data1)
plt.ylabel("error norm value (m)")
plt.xlabel("t(s)")
plt.show()
