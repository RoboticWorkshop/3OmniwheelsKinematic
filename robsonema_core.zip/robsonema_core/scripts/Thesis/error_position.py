#!/usr/bin/env python
import rospy
from std_msgs.msg import Float32

range_data = 0

class Server:
	def __init__(self):
		self.myfile = open("position_error1.txt","w")

	def callback(self, data):
		error = data.data
		rospy.loginfo(error)
		self.myfile.write(str(error))		
		self.myfile.write("\n")
		delay.sleep()	

if __name__ == '__main__':
	rospy.init_node('get_position_error_node')
	delay = rospy.Rate(10)
	server = Server()
	try:
		rospy.Subscriber("/position1_error", Float32, server.callback)
		rospy.spin()
	except rospy.ROSInterruptException:
		myfile.close()
		pass
