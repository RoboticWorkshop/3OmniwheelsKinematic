#!/usr/bin/env python

import sympy as sp
from numpy import *
import matplotlib.pyplot as plt
from numpy.linalg import inv
import rospy
from geometry_msgs.msg import Vector3
from std_msgs.msg import Float32
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import Int32


class Server:
	def __init__(self):
		self.l = 0.20		
		self.r = 0.05
		self.alp = array([[0*pi/180, 120*pi/180, 240*pi/180]]).T #robot specification
		self.th = 0. * pi / 180.
		self.Jr = self.jacobianR()
		self.x_des = sp.Matrix([[0., 0., 0.]]).transpose()
		self.x = sp.Matrix([[0, 0, 0]]).transpose()#koordinat actual
		self.lamda = array([[20, 20]])
		self.skill = 0
		self.detik = 0
		self.positioning = 0
		#camera parameter
		self.cam_des = sp.Matrix([[240, 0, 0.]]).transpose()
		self.cam = sp.Matrix([[0., 0., 0.]]).transpose()
		self.cam_rot = sp.Matrix([[1,0,0], [0,0,0], [0,0,0]])
		self.kp1 = 1
		self.v_lambda = sp.Matrix([[self.kp1 , 0., 0.], [0., 0., 0.], [0., 0., 0.]])
		self.iLs = self.camera_matrix()
		print "kinematic control robot3 running"

	def jacobianR(self):
		Js=array([[0.,0.,0.],[0.,0.,0.],[0.,0.,0.]])
		Js[0,0]=sp.cos(self.alp[0,0])
		Js[0,1]=sp.cos(self.alp[1,0])
		Js[0,2]=sp.cos(self.alp[2,0])
		Js[1,0]=sp.sin(self.alp[0,0])
		Js[1,1]=sp.sin(self.alp[1,0])
		Js[1,2]=sp.sin(self.alp[2,0])
		Js[2,0]=1./self.l
		Js[2,1]=1./self.l
		Js[2,2]=1./self.l
		#print(Jr)
		return self.r*Js
	
	def jacobianW(self,th,Jr):
		rotZ = array([[sp.cos(th), -sp.sin(th), 0.], [sp.sin(th), sp.cos(th), 0.], [0., 0., 1]])
		#print(rotZ)
		Jw = rotZ.dot(Jr)
		return sp.Matrix(Jw)

	def camera_matrix(self):
		Ls = sp.Matrix([[0,0,0],[0,0,0],[0,0,0]])
		Ls[0,0] = -1. / 0.42
		Ls[0,1] = 0
		Ls[0,2] = 240. / 0.42
		Ls[1,0] = 0
		Ls[1,1] = -1./ 0.42
		Ls[1,2] = 300./0.42
		Ls[2,0] = 0
		Ls[2,1] = 0
		Ls[2,2] = 50. * (2. / 0.42)
		Lsinv = Ls.inv()
		#sp.pprint(Ls)
		#sp.pprint(Lsinv)
		return Lsinv

	def get_camera(self, dat):
		self.cam[0,0] = dat.x
		self.cam[1,0] = dat.y
		self.cam[2,0] = -dat.z
		#print self.cam
		self.main()
		
	def get_odom(self, dat):
		self.x[0, 0] = dat.x #present x coordinate
		self.x[1, 0] = dat.y #present y coordinate
		self.x[2, 0] = dat.z * pi / 180. #present heading in radian
		self.th = self.x[2, 0]
		#print self.positioning
		self.main()
		
	def get_positioning(self,dat):
		self.positioning = dat.data

	def pwm_leveling(self, w):
		#====================== W1 ====================
		if(w[0,0]>0.4) and (w[0,0]<125):
			w[0,0] = 125
		elif (w[0,0]<-0.4) and (w[0,0]>-125):
			w[0,0] = -125
		elif(w[0,0]>400):
			w[0,0] = 400
		elif (w[0,0]<-400):
			w[0,0] = -400
		#====================== W2 ====================
		if(w[1,0]>3) and (w[1,0]<125):
			w[1,0] = 125
		elif (w[1,0]<-3) and (w[1,0]>-125):
			w[1,0] = -125
		elif(w[1,0]>400):
			w[1,0] = 400
		elif (w[1,0]<-400):
			w[1,0] = -400
		#====================== W3 ====================
		if(w[2,0]>3) and (w[2,0]<125):
			w[2,0] = 125
		elif (w[2,0]<-3) and (w[2,0]>-125):
			w[2,0] = -125
		elif(w[2,0]>400):
			w[2,0] = 400
		elif (w[2,0]<-400):
			w[2,0] = -400
		pwm.y = w[0,0]
		pwm.z = w[1,0]
		pwm.x = w[2,0]
		pub.publish(pwm)
		print w
		#print pwm

	def pwm_leveling1(self, w):
		if(w[0,0]>0.4) and (w[0,0]<125):
			w[0,0] = 125
		elif (w[0,0]<-0.4) and (w[0,0]>-125):
			w[0,0] = -125
		elif(w[0,0]>400):
			w[0,0] = 400
		elif (w[0,0]<-400):
			w[0,0] = -400
		w[1,0] = -0.5*w[0,0]
		w[2,0] = -0.5*w[0,0]
		#====================== W2 ====================
		if(w[1,0]>3) and (w[1,0]<125):
			w[1,0] = 125
		elif (w[1,0]<-3) and (w[1,0]>-125):
			w[1,0] = -125
		elif(w[1,0]>400):
			w[1,0] = 400
		elif (w[1,0]<-400):
			w[1,0] = -400
		#====================== W3 ====================
		if(w[2,0]>3) and (w[2,0]<125):
			w[2,0] = 125
		elif (w[2,0]<-3) and (w[2,0]>-125):
			w[2,0] = -125
		elif(w[2,0]>400):
			w[2,0] = 400
		elif (w[2,0]<-400):
			w[2,0] = -400
		pwm.y = w[0,0]
		pwm.z = w[1,0]
		pwm.x = w[2,0]
		pub.publish(pwm)
		rospy.loginfo(pwm)
		#print pwm

	def control(self):
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#==================== compute error ==================================
		#desired 0 - 180
		if(self.x_des[2, 0] >= 0) and (self.x_des[2, 0] <= pi):
			self.Er = self.x_des - self.x	
			if(self.x[2,0] > pi) and (self.x[2,0] < 2*pi):
				self.Er[2,0] = self.Er[2,0] % (2*pi)	
		#desired 181 - 359
		elif(self.x_des[2, 0] > pi) and (self.x_des[2, 0] < 2*pi):
			self.Er = self.x_des - self.x	
			if(self.x[2,0] >= 0) and (self.x[2,0] < pi):
				self.Er[2,0] = self.Er[2,0] - (2*pi)
		if(self.Er.norm()<0.1):
			self.Er = self.Er * 0.
			self.positioning = 2
			self.detik = 0
		else:
			self.detik = self.detik + 1
		#print self.Er
		#rospy.loginfo(er)
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*self.Er
		#print self.detik
		self.pwm_leveling(w)	
	
	def control2(self):
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#==================== compute error ==================================
		#desired 0 - 180
		self.Er = self.x_des - self.x	
		self.Er[0,0] = 0
		self.Er[1,0] = self.x_des[1,0]
		if(self.x_des[2, 0] >= 0) and (self.x_des[2, 0] <= pi):	
			if(self.x[2,0] > pi) and (self.x[2,0] < 2*pi):
				self.Er[2,0] = self.Er[2,0] % (2*pi)	
		#desired 181 - 359
		elif(self.x_des[2, 0] > pi) and (self.x_des[2, 0] < 2*pi):
			if(self.x[2,0] >= 0) and (self.x[2,0] < pi):
				self.Er[2,0] = self.Er[2,0] - (2*pi)
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*self.Er
		self.pwm_leveling(w)	

	def visual_servoing(self):
		J = self.jacobianW(self.th, self.Jr)
		vJinv = sp.Matrix(self.Jr).inv()
		self.Jinv = J.inv()
		er = self.cam_des - self.cam
		rr = self.cam_rot * er
		#rr[0,0] = 10
		#rr[1,0] = -10
		#rr[2,0] = 0
		rr[2,0] = 0.*pi/180 - self.x[2,0] #heading ball
		print rr.norm()
		#if(self.detik < 20):
			#self.v_lambda[0,0] = self.v_lambda[0,0] *
		if(rr.norm()<30):
			rr[0, 0] = rr[0,0] * 0
			rr[1, 0] = rr[1,0] * 0
			rr[2, 0] = rr[2,0] * 0
			self.detik=0
			w = vJinv * (self.v_lambda * self.iLs * rr)
		else:
			self.detik = self.detik+1
			w = vJinv * (self.v_lambda * self.iLs * rr)
		self.pwm_leveling1(w)

	def main(self):
		#print self.skill
		if(self.detik < 10):
			self.kp = self.lamda[0,0]*0.25
		elif(self.detik < 30):
			self.kp = self.lamda[0,0]*0.5
		elif(self.detik < 50):
			self.kp = self.lamda[0,0]*0.75
		else:
			self.kp = self.lamda[0,0]
		#print self.kp
		if(self.positioning == 2):
			self.visual_servoing()
		elif(self.positioning == 1):
			self.kp = 20
			self.x_des[0,0] = 3.0
			self.x_des[1,0] = 0.0
			self.x_des[2,0] = 0.0
			self.control()
		else:
			self.detik = 0
	
if __name__ == "__main__":
	rospy.init_node("robot3_kinematic_node")
	pub = rospy.Publisher("robot3/pwm_val", Vector3, queue_size=2)
	pwm = Vector3()
	er = Float32()
	odom = Vector3()
	server = Server()
	try:
		rospy.Subscriber('robot3/odometry', Vector3, server.get_odom)
		rospy.Subscriber('robot3/camera', Vector3, server.get_camera)
		rospy.Subscriber('robot3/positioning', Int32, server.get_positioning)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass