#!/usr/bin/env python

import sympy as sp
from numpy import *
import matplotlib.pyplot as plt
from numpy.linalg import inv
import rospy
from geometry_msgs.msg import Vector3
from std_msgs.msg import Float32
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import Int32


class Server:
	def __init__(self):
		self.alp = array([[0*pi/180, 120*pi/180, 240*pi/180]]).T #robot specification
		self.cam_des = sp.Matrix([[160., 90*pi*180, -60.]]).transpose()
		self.cam = sp.Matrix([[0., 0., 0.]]).transpose()
		self.cam_rot = sp.Matrix([[1,0,0], [0,0,1], [0,0,0]])
		self.l = 0.20		
		self.r = 0.05
		self.Jr = self.jacobianR()
		self.th = 0. * pi / 180.
		self.x_des = sp.Matrix([[0., 0., 0.]]).transpose()
		self.x = sp.Matrix([[0, 0, 0]]).transpose()#koordinat actual
		self.lamda = array([[20, 20]])
		self.kp1 = 1.05 #0.85
		self.kp2 = 1.65 # 1.75
		self.kp3 = 1.
		self.v_lambda = sp.Matrix([[self.kp1 , 0., 0.], [0., self.kp2, 0.], [0., 0., self.kp3]])
		self.iLs = self.camera_matrix()
		self.skill = 3
		self.lastcm = 0
		self.diff = 0
		sp.pprint(self.Jr)
		#sp.pprint(self.iLs)
		print "kinematic control running"

	def jacobianR(self):
		Js=array([[0.,0.,0.],[0.,0.,0.],[0.,0.,0.]])
		Js[0,0]=sp.cos(self.alp[0,0])
		Js[0,1]=sp.cos(self.alp[1,0])
		Js[0,2]=sp.cos(self.alp[2,0])
		Js[1,0]=sp.sin(self.alp[0,0])
		Js[1,1]=sp.sin(self.alp[1,0])
		Js[1,2]=sp.sin(self.alp[2,0])
		Js[2,0]=1./self.l
		Js[2,1]=1./self.l
		Js[2,2]=1./self.l
		#print(Jr)
		return self.r*Js
	
	def jacobianW(self,th,Jr):
		rotZ = array([[sp.cos(th), -sp.sin(th), 0.], [sp.sin(th), sp.cos(th), 0.], [0., 0., 1]])
		#print(rotZ)
		Jw = rotZ.dot(Jr)
		return sp.Matrix(Jw)
		
	def camera_matrix(self):
		Ls = sp.Matrix([[0,0,0],[0,0,0],[0,0,0]])
		Ls[0,0] = -1. / 0.33
		Ls[0,1] = 0
		Ls[0,2] = 160. / 0.33
		Ls[1,0] = 0
		Ls[1,1] = -1./ 0.33
		Ls[1,2] = 175./0.33
		Ls[2,0] = 0
		Ls[2,1] = 0
		Ls[2,2] = 60. * (2. / 0.33)
		Lsinv = Ls.inv()
		sp.pprint(Ls)
		sp.pprint(Lsinv)
		return Lsinv

	def get_odom(self, dat):
		self.x[0, 0] = dat.x #present x coordinate
		self.x[1, 0] = dat.y #present y coordinate
		self.x[2, 0] = dat.z * pi / 180. #present heading in radian
		self.th = self.x[2, 0]
		#print self.th
		self.main()

	def get_skill(self, dat):
		self.skill = dat.data[0]
		self.x_des[0, 0] = dat.data[1]
		self.x_des[1, 0] = dat.data[2]
		self.x_des[2, 0] = dat.data[3]
		self.main()

	def get_camera(self, dat):
		self.cam[0,0] = dat.x
		self.cam[1,0] = dat.y
		self.cam[2,0] = -dat.z
		#print self.cam
		self.main()

	def pwm_leveling(self, w):
		#====================== W1 ====================
		if(w[0,0]>0.4) and (w[0,0]<125):
			w[0,0] = 125
		elif (w[0,0]<-0.4) and (w[0,0]>-125):
			w[0,0] = -125
		elif(w[0,0]>400):
			w[0,0] = 400
		elif (w[0,0]<-400):
			w[0,0] = -400
		#====================== W2 ====================
		if(w[1,0]>3) and (w[1,0]<150):
			w[1,0] = 150
		elif (w[1,0]<-3) and (w[1,0]>-150):
			w[1,0] = -150
		elif(w[1,0]>400):
			w[1,0] = 400
		elif (w[1,0]<-400):
			w[1,0] = -400
		#====================== W3 ====================
		if(w[2,0]>3) and (w[2,0]<150):
			w[2,0] = 100
		elif (w[2,0]<-3) and (w[2,0]>-150):
			w[2,0] = -150
		elif(w[2,0]>400):
			w[2,0] = 400
		elif (w[2,0]<-400):
			w[2,0] = -400
		pwm.y = w[0,0]
		pwm.z = w[1,0]
		pwm.x = w[2,0]
		pub.publish(pwm)
		#print w
		#print pwm

	def pwm_leveling1(self, w):
		#====================== W1 ====================
		if(w[0,0]>0.4) and (w[0,0]<100):
			w[0,0] = 100
		elif (w[0,0]<-0.4) and (w[0,0]>-100):
			w[0,0] = -100
		if(w[0,0]>400):
			w[0,0] = 400
		elif (w[0,0]<-400):
			w[0,0] = -400
		#====================== W2 ====================
		if(w[1,0]>3) and (w[1,0]<100):
			w[1,0] = 100
		elif (w[1,0]<-3) and (w[1,0]>-100):
			w[1,0] = -100
		if(w[1,0]>400):
			w[1,0] = 400
		elif (w[1,0]<-400):
			w[1,0] = -400
		#====================== W3 ====================
		if(w[2,0]>3) and (w[2,0]<100):
			w[2,0] = 100
		elif (w[2,0]<-3) and (w[2,0]>-100):
			w[2,0] = -100
		if(w[2,0]>400):
			w[2,0] = 400
		elif (w[2,0]<-400):
			w[2,0] = -400
		pwm.y = w[0,0]
		pwm.z = w[1,0]
		pwm.x = w[2,0]
		pub.publish(pwm)
		#print w
		#print pwm

	def visual_servoing(self):
		J = self.jacobianW(self.th, self.Jr)
		vJinv = sp.Matrix(self.Jr).inv()
		self.Jinv = J.inv()
		er = self.cam_des - self.cam
		rr = self.cam_rot * er
		#rr[0,0] = 0
		#rr[1,0] = 0
		rr[2,0] = self.cam[1,0] - (90.*pi/180.) #heading ball
		#rr[2,0] = (self.cam[1,0]*180./pi) - 90. #heading ball
		#rr[2,0] = heading_error
		#print rr
		#if((self.cam[1,0] - self.lastcm) < 0):
			#self.diff = 2
		#elif((self.cam[1,0] - self.lastcm) > 0):
			#self.diff = -2
		#if(self.cam[1,0] > 2.15) and (self.cam[1,0] < 2.16):
		#	rr[0, 0] = 0
		#	rr[1, 0] = 0
		#	rr[2, 0] = self.diff
		if(rr.norm()<20):
			rr[0, 0] = rr[0,0] * 0
			rr[1, 0] = rr[1,0] * 0
			rr[2, 0] = rr[2,0] * 0
		print rr
		w = vJinv * (self.v_lambda * self.iLs * rr)
		self.lastcm = self.cam[1,0]
		self.pwm_leveling1(w)	

	def control(self):
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#==================== compute error ==================================
		#desired 0 - 180
		if(self.x_des[2, 0] >= 0) and (self.x_des[2, 0] <= pi):
			self.Er = self.x_des - self.x	
			if(self.x[2,0] > pi) and (self.x[2,0] < 2*pi):
				self.Er[2,0] = self.Er[2,0] % (2*pi)	
		#desired 181 - 359
		elif(self.x_des[2, 0] > pi) and (self.x_des[2, 0] < 2*pi):
			self.Er = self.x_des - self.x	
			if(self.x[2,0] >= 0) and (self.x[2,0] < pi):
				self.Er[2,0] = self.Er[2,0] - (2*pi)
		if(self.Er.norm()<0.02):
			self.Er = self.Er * 0.
			self.detik = 0
		else:
			self.detik = self.detik + 1
		#print self.Er
		#rospy.loginfo(er)
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*self.Er
		print self.detik
		self.pwm_leveling(w)	
	
	def control2(self):
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#==================== compute error ==================================
		#desired 0 - 180
		self.Er = self.x_des	
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*self.Er
		self.pwm_leveling(w)	

	def main(self):
		#print self.skill
		if(self.skill == 0):#command stop
			pwm.y = 0
			pwm.z = 0
			pwm.x = 0
			pub.publish(pwm)
			#print "ROBOT STOP"
		elif(self.skill == 1):#command position
			if(self.detik < 10):
				self.kp = self.lamda[0,0]*0.5
			elif(self.detik < 30):
				self.kp = self.lamda[0,0]*0.75
			else:
				self.kp = self.lamda[0,0]
			self.control()
			#print "ROBOT POSITIONING"

		elif(self.skill == 2):#command independent movement
			self.kp = self.lamda[0,1]
			self.control2()
			#print "ROBOT INDEPENDENT"

		elif(self.skill == 3):#command ball_finder
			#print "BALL FINDER MODE"
			self.visual_servoing()

		elif(self.skill == 4):#command ball_finder
			#print "PASS BALL"
			self.skill = 0

		elif(self.skill == 5):#command ball_finder
			#print "KICK BALL"
			self.skill = 0
	
if __name__ == "__main__":
	rospy.init_node("robot1_kinematic_node")
	pub = rospy.Publisher("robot1/pwm_val", Vector3, queue_size=2)
	pwm = Vector3()
	er = Float32()
	odom = Vector3()
	server = Server()
	try:
		#rospy.Subscriber('/target', Int32, server.get_target)
		rospy.Subscriber('robot1/skill', Float32MultiArray, server.get_skill)
		rospy.Subscriber('robot1/odometry', Vector3, server.get_odom)
		rospy.Subscriber('robot1/camera', Vector3, server.get_camera)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass