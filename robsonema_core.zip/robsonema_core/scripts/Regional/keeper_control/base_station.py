#!/usr/bin/env python

from __future__ import print_function

import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy

from std_msgs.msg import Int32MultiArray
from std_msgs.msg import String

import sys, select, termios, tty

msg = """
Welcome to -- ROBSONEMA BASE STATION TELEOP KEY --
---------------------------
===== general command =====
s = stop all robot
S = Start ball finder

===== positioning command =====
q = kick off
w = corner kick
e = goal kick

===== independent movement command =====
i = move forward
l = move right
j = move left
m = move backward

===== kicking ball command =====
p = pass
o = shoot

h = HELP

CTRL-C to quit
"""

moveBindings = {
		's':(0,0,"STOP",0),
		'S':(3,0,"START",1), 
		'q':(1,0,"KICK OFF",2),
		'w':(1,1,"CORNER KICK",2),
		'e':(1,2,"GOAL KICK",2),
		'i':(2,11,"MOVE FORWARD",1),
		'l':(2,12,"MOVE RIGHT",1),
		'j':(2,-12,"MOVE LEFT",1),
		'm':(2,-11,"MOVE BACKWARD",1),
		'p':(4,15,"PASS",1),
		'o':(5,17,"KICK",1),
		'h':(20,0,"HELP",1),
		}

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)

	rospy.init_node('base_station_teleop_node')
	pub = rospy.Publisher('base_station_command', Int32MultiArray, queue_size = 10)
	command = Int32MultiArray()
	note = String()
	command.data = [0,0,0]
	try:
		print(msg)
		while(1):
			key = getKey()
			if key in moveBindings.keys():
				skill = moveBindings[key][0]
				code = moveBindings[key][1]
				sym = moveBindings[key][2]
				act = moveBindings[key][3]
			else:
				skill = 0
				code = 0
				sym = "STOP"
				if (key == '\x03'):
					break
			if(skill == 20):
				print(msg)
			else:
				command.data[0] = skill
				command.data[1] = code
				command.data[2] = act
				note.data = sym
			pub.publish(command)
			print(note)
		
	except Exception as e:
		print(e)

	finally:
		pub.publish(command)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


