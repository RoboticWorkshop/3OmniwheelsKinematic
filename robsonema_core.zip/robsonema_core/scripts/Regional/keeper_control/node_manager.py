#!/usr/bin/env python

import rospy
from numpy import *
from geometry_msgs.msg import Vector3
from std_msgs.msg import String
from std_msgs.msg import Int32
from std_msgs.msg import Float32
from std_msgs.msg import Int32MultiArray
from std_msgs.msg import Float32MultiArray

class Server:
	def __init__(self):
		self.destination1 = array([[0., 0., 270], 
									[2., 4., 0.], 
									[2., 3., 0.],
									[2., 4., 0.], 
									[2., 3., 0.],
									[2., 4., 0.], 
									[2., 3., 0.]
									]) #robot 1
		self.destination2 = array([[0., 0., 0], [0., 0., 0.], [0., 0., 0]]) #robot 2
		self.odom = array([[0., 0., 0.], [0., 0., 0.], [0., 0., 0.]])
		self.cmd = array([[0, 0]])
		self.positioning = 0
		print "node manager running"

	def odometry_fw(self, dat):#subscribe odometry robot fw
		self.odom[0,0] = dat.x
		self.odom[0,1] = dat.y
		self.odom[0,2] = dat.z
		#self.command_skill_robot1()

	def odometry_cb(self, dat):#subscribe odometry robot cb
		self.odom[1,0] = dat.x
		self.odom[1,1] = dat.y
		self.odom[1,2] = dat.z		
		#self.command_skill_robot2()

	def odometry_gk(self, dat):#subscribe odometry robot gw
		self.odom[2,0] = dat.x
		self.odom[2,1] = dat.y
		self.odom[2,2] = dat.z
		#self.command_skill_robot3()

	def command_input(self, dat):#input command from keyboard
		self.cmd[0,0] = dat.data[0]
		self.cmd[0,1] = dat.data[1]
		self.positioning = dat.data[2]
		self.command_skill_robot1()
		self.command_skill_robot3()

	def command_skill_robot1(self):#publish skill
		dat1.data[0] = self.positioning
		if(self.positioning == 2): #positioning
			dat1.data[1] = self.destination1[self.cmd[0,1], 0]
			dat1.data[2] = self.destination1[self.cmd[0,1], 1]
			theta1 = self.destination1[self.cmd[0,1], 2] * pi /180
			dat1.data[3] = theta1
		robot1_pub.publish(dat1)
		
	def command_skill_robot3(self):#publish skill
		robot3_pub.publish(self.positioning)
		
if __name__ == "__main__":
	rospy.init_node('robot3_manager_node')
	robot1_pub = rospy.Publisher('robot1/skill', Float32MultiArray, queue_size = 10)
	robot2_pub = rospy.Publisher('robot2/skill', Float32MultiArray, queue_size = 10)
	robot3_pub = rospy.Publisher('robot3/action', Int32, queue_size = 10)
	dat1 = Float32MultiArray()
	dat2 = Float32MultiArray()
	dat3 = Float32MultiArray()
	server = Server()
	dat1.data = [0, 0., 0., 0., 0., 0]
	dat2.data = [0, 0., 0., 0., 0., 0]
	dat3.data = [0, 0., 0., 0., 0., 0]
	try:
		rospy.Subscriber('robot1/odometry', Vector3, server.odometry_fw)
		rospy.Subscriber('robot2/odometry', Vector3, server.odometry_cb)
		rospy.Subscriber('robot3/odometry', Vector3, server.odometry_gk)
		rospy.Subscriber('base_station_command', Int32MultiArray, server.command_input)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass