#!/usr/bin/env python

import rospy
import random as rd
from numpy import *
from geometry_msgs.msg import Vector3
from std_msgs.msg import String
from std_msgs.msg import Int32
from std_msgs.msg import Float32
from std_msgs.msg import Int32MultiArray
from std_msgs.msg import Float32MultiArray

class Server:
	def __init__(self):
		self.destination1 = array([[0., 0., 0.], 
									[2., 4., 0.], 
									[2., 3., 0.],
									[2., 4., 0.], 
									[2., 3., 0.],
									[2., 4., 0.], 
									[2., 3., 0.]
									]) #robot 1
		self.target1 = array([[1.5, 6.0, 0.], [3.0, 6.0, 0.], [4.5, 6.0, 0.],
							  [1.5, 4.5, 0.], [3.0, 4.5, 0.], [4.5, 4.5, 0.],
							  [1.5, 3.0, 0.], [3.0, 3.0, 0.], [4.5, 3.0, 0.]])
		self.distance1 = array([0., 0., 0., 0., 0., 0., 0., 0., 0.])
		self.kick_mode1 = array([0, 1, 1, 0, 1, 0, 0, 0, 1, 0])
		self.index_kick_mode1 = 0
		self.lock1 = 0
		self.index_lokalisasi = 0

		self.destination2 = array([[0., 0., 0.], 
									[0., 0., 0.], 
									[0., 0., 0.],
									[0., 0., 0.],
									[0., 0., 0.],
									[0., 0., 0.],
									[0., 0., 0.]
									]) #robot 2
		self.target2 = array([[3.0, 4.5, 0.], [1.5, 4.5, 0.], [3.0, 4.5, 0.]])
		self.odom = array([[0., 0., 0.], [0., 0., 0.], [0., 0., 0.]])
		self.cmd = array([[0, 0]])
		self.positioning = 3
		self.sp = 2
		self.robot1_ball = 0
		print "node manager running"
		print self.positioning

	def odometry_fw(self, dat):#subscribe odometry robot fw
		self.odom[0,0] = dat.x
		self.odom[0,1] = dat.y
		self.odom[0,2] = dat.z
		#self.command_skill_robot1()

	def odometry_cb(self, dat):#subscribe odometry robot cb
		self.odom[1,0] = dat.x
		self.odom[1,1] = dat.y
		self.odom[1,2] = dat.z		
		#self.command_skill_robot2()

	def odometry_gk(self, dat):#subscribe odometry robot gw
		self.odom[2,0] = dat.x
		self.odom[2,1] = dat.y
		self.odom[2,2] = dat.z
		#self.command_skill_robot3()

	def get_ball_position1(self, dat):
		self.robot1_ball = dat.data
		self.command_skill_robot1()

	def get_acc(self,dat):
		self.clear = dat.data
		if(self.clear == 1):
			self.index_lokalisasi = self.index_lokalisasi + 1
			if(self.index_lokalisasi > 4):
				self.positioning = 0
			else :
				self.positioning = 5
		self.clear = 0

	def command_input(self, dat):#input command from keyboard
		self.cmd[0,0] = dat.data[0]
		self.cmd[0,1] = dat.data[1]
		self.positioning = dat.data[2]
		self.command_skill_robot1()
		self.command_skill_robot3()

	
	def command_skill_robot1(self):#publish skill
		dat1.data[0] = self.positioning
		if(self.positioning == 2): #positioning
			dat1.data[1] = self.destination1[self.cmd[0,1], 0]
			dat1.data[2] = self.destination1[self.cmd[0,1], 1]
			theta1 = self.destination1[self.cmd[0,1], 2] * pi /180
			dat1.data[3] = theta1

		elif(self.positioning == 3): #game on / start
			if(self.robot1_ball == 1):
				if(self.lock1 == 0):
					self.index_kick_mode1 = 1#rd.randint(0,9) 
					self.lock1 = 1
				if(self.kick_mode1[self.index_kick_mode1]==1): # goto position
					for i in range(0,9):
						self.distance1[i] = sqrt((self.odom[0,0] - self.target1[i,0])**2 + (self.odom[0,1] - self.target1[i,1])**2)
					index_target = argmin(self.distance1)
					dat1.data[1] = self.target1[index_target, 0]
					dat1.data[2] = self.target1[index_target, 1]
					theta1 = self.target1[index_target, 2] * pi /180
					dat1.data[3] = theta1
					print "GO TO POSITION\t", dat1.data[1], dat1.data[2], dat1.data[3]
				else:
					dat1.data[1] = self.odom[0,0]
					dat1.data[2] = self.odom[0,1]
					theta1 = self.odom[0,2]
					dat1.data[3] = theta1
					#print "DIRECT KICK\t", dat1.data[1], dat1.data[2], dat1.data[3]

			elif(self.robot1_ball == 0):
				self.lock1 = 0
				dat1.data[1] = 0
				dat1.data[2] = 0
				theta1 = 0 * pi /180
				dat1.data[3] = theta1

		elif(self.positioning == 5): #update positioning
			if(self.odom[0,1] >= 4.5):
				if(self.index_lokalisasi == 1):
					dat1.data[1] = 5.
					dat1.data[2] = 6.
				elif(self.index_lokalisasi == 3):
					dat1.data[1] = 5.
					dat1.data[2] = 5.
			else:
				dat1.data[1] = 5.
				dat1.data[2] = 3.
			theta1 = 0 * pi /180
			dat1.data[3] = theta1
			robot1_lokalisasi.publish(self.index_lokalisasi)

		robot1_pub.publish(dat1)
		robot1_action.publish(self.positioning)
		rospy.loginfo("%d, %d", self.positioning, self.index_lokalisasi)
		
	def command_skill_robot3(self):#publish skill
		robot3_pub.publish(self.positioning)
		
if __name__ == "__main__":
	rospy.init_node('robot3_manager_node')
	robot1_pub = rospy.Publisher('robot1/skill', Float32MultiArray, queue_size = 10)
	robot1_action = rospy.Publisher('robot1/action', Int32, queue_size = 10)
	robot1_lokalisasi = rospy.Publisher('robot1/localization', Int32, queue_size = 10)
	robot2_pub = rospy.Publisher('robot2/skill', Float32MultiArray, queue_size = 10)
	robot3_pub = rospy.Publisher('robot3/action', Int32, queue_size = 10)
	dat1 = Float32MultiArray()
	dat2 = Float32MultiArray()
	server = Server()
	dat1.data = [0, 0., 0., 0., 0., 0]
	dat2.data = [0, 0., 0., 0., 0., 0]
	try:
		rospy.Subscriber('robot1/odometry', Vector3, server.odometry_fw)
		rospy.Subscriber('robot1/ball_position', Int32, server.get_ball_position1)
		rospy.Subscriber('robot1/command_clear', Int32, server.get_acc)
		rospy.Subscriber('robot2/odometry', Vector3, server.odometry_cb)
		rospy.Subscriber('robot3/odometry', Vector3, server.odometry_gk)
		rospy.Subscriber('base_station_command', Int32MultiArray, server.command_input)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass