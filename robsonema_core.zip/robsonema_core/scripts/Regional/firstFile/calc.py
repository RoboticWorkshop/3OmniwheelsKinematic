#!/usr/bin/env python

import sympy as sp
from numpy import *

a = (90.*pi/180.) % (2*pi)
b = (180.*pi/180.) % (2*pi)
c = (270.*pi/180.) % (2*pi)
d = (360.*pi/180.) % (2*pi)

print a, b, c, d