#!/usr/bin/env python

import sympy as sp
from numpy import *
import matplotlib.pyplot as plt
import rospy
from geometry_msgs.msg import Vector3
from std_msgs.msg import Int32

class Server:
	def __init__(self):
		self.lenc = [0,0,0]
		self.enc = [0,0,0]
		self.position = [0,0,0]
		self.land=0
		self.ts = 0.10#0.04
		self.th = 0.*pi/180.
	def get_encoder(self, dat):
		k = 3.956 * pi/180.
		self.enc[0] = dat.y*k/self.ts #w1 y = belakang
		self.enc[1] = dat.z*k/self.ts #w2 z = kanan
		self.enc[2] = dat.x*k/self.ts #w3 x = kiri
		self.update_position()
	def get_landmark(self, dat):
		self.land = dat.data
		self.update_position()
	def update_position(self):
		l = 0.20		
		r = 0.05
		rot = 90.*pi/180.
		w_enc = array([[0.,0.,0.]]).T
		x_dot = array([[0.,0.,0.]]).T
		w_enc[0,0] = self.enc[0]# - self.lenc[0]
		w_enc[1,0] = self.enc[1]# - self.lenc[1]
		w_enc[2,0] = self.enc[2]# - self.lenc[2]
		#print w_enc[0,0], w_enc[1,0], w_enc[2,0]
		#compute x dot
		x_dot[0] = -r * (w_enc[0,0]*sp.cos(self.th) + w_enc[1,0] * (-1./2. * sp.cos(self.th) - sqrt(3.)/2. * sp.sin(self.th)) + w_enc[2,0] * (-1./2. * sp.cos(self.th) + sqrt(3.)/2. * sp.sin(self.th)))
		x_dot[1] = r * (w_enc[0,0]*sp.sin(self.th) + w_enc[1,0] * (-1./2. * sp.sin(self.th) - sqrt(3.)/2. * sp.cos(self.th)) + w_enc[2,0] * (-1./2. * sp.sin(self.th) + sqrt(3.)/2. * sp.cos(self.th)))
		x_dot[2] = 3.*(r/l)*(w_enc[0,0]+w_enc[1,0]+w_enc[2,0])
		#update position
		if(self.land == 0):#normal condition
			self.position[0] = self.position[0] + x_dot[0] * self.ts #x
			self.position[1] = self.position[1] + x_dot[1] * self.ts #y
			self.position[2] = self.position[2] + x_dot[2] * self.ts #th
			self.position[2] = ((self.position[2]) % (2*pi)) - pi
		elif(self.land == 1):#reading landmark
			self.position[0] = 0 #x
			self.position[1] = 0 #y
		elif(self.land == 2):#reading line
			self.position[2] = 0 #th
		else:#exit
			self.position[0] = 0#x
			self.position[1] = 0#y
			self.position[2] = 0#th
		odom.x = (self.position[0]*sp.cos(rot) - self.position[1]*sp.sin(rot))*10
		odom.y = (self.position[0]*sp.sin(rot) + self.position[1]*sp.cos(rot))*10
		odom.z = self.position[2] * 180. / pi
		#update theta
		self.th = self.position[2]
		print odom.x, odom.y, odom.z
		pub.publish(odom)
		#update encoder 
		#self.lenc[0] = self.enc[0]
		#self.lenc[1] = self.enc[1]
		#self.lenc[2] = self.enc[2]

if __name__ == "__main__":
	rospy.init_node("position_updater")
	pub = rospy.Publisher("odometry", Vector3, queue_size=10);
	odom = Vector3()
	server = Server()
	try:
		rospy.Subscriber('/encoder', Vector3, server.get_encoder)
		rospy.Subscriber('/landmark', Int32, server.get_landmark)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass