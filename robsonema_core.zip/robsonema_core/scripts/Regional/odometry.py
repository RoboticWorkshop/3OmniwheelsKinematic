#!/usr/bin/env python

import sympy as sp
import rospy
from numpy import *
from numpy.linalg import inv
from geometry_msgs.msg import Vector3

class Server:
	def __init__(self):
		self.alp = sp.Matrix([[0*pi/180, 120*pi/180, 240*pi/180]]).transpose() #robot specification
		self.enc = sp.Matrix([[0., 0., 0.]]).transpose()
		self.position = sp.Matrix([[0.0*10/6.63, 0., 0.]]).transpose()
		self.ts = 0.1#0.0635
		self.th = 0*pi/180.
		self.l = 0.20		
		self.r = 0.05
		self.Jr = self.jacobianR()
		self.w_enc = array([[0.,0.,0.]]).T

	def get_encoder(self, dat):
		k = 3.956 * pi/180.
		#k = 1.
		self.enc[0, 0] = dat.y*k#w1 y = belakang
		self.enc[1, 0] = dat.z*k #w2 z = kanan
		self.enc[2, 0] = dat.x*k #w3 x = kiri
		self.update_position()

	def get_update(self, dat):
		odom.x = dat.x
		odom.y = dat.y
		odom.z = dat.z
		self.position[0,0] = odom.x * 10 / 6.63
		self.position[1,0] = odom.y * 14.6 / 9.5
		self.position[2,0] = ((odom.z * pi / 180.) * 15.35 / 4.71238)
		pub.publish(odom)

	def jacobianR(self):
		Js=sp.Matrix([[0.,0.,0.],[0.,0.,0.],[0.,0.,0.]])
		Js[0,0]=sp.cos(self.alp[0,0])
		Js[0,1]=sp.cos(self.alp[1,0])
		Js[0,2]=sp.cos(self.alp[2,0])
		Js[1,0]=sp.sin(self.alp[0,0])
		Js[1,1]=sp.sin(self.alp[1,0])
		Js[1,2]=sp.sin(self.alp[2,0])
		Js[2,0]=1./self.l
		Js[2,1]=1./self.l
		Js[2,2]=1./self.l
		#print(Jr)
		return self.r*Js

	def jacobianW(self,th,Jr):
		rotZ = sp.Matrix([[sp.cos(th), -sp.sin(th), 0.], [sp.sin(th), sp.cos(th), 0.], [0., 0., 1]])
		#print(rotZ)
		Jw = rotZ*Jr
		return Jw

	def update_position(self):
		#compute error position
		#compute x dot
		#==================== position update from encoder =====================================
		self.w_enc[0,0] = self.enc[0]/self.ts#w1
		self.w_enc[1,0] = self.enc[1]/self.ts#w2
		self.w_enc[2,0] = self.enc[2]/self.ts#w3
		J = self.jacobianW(self.th, self.Jr)
		x_dot = J*self.w_enc
		self.Jinv = J.inv()
		#update position
		self.position[0,0] = self.position[0,0] + x_dot[0,0] * self.ts #x
		self.position[1,0] = self.position[1,0] + x_dot[1,0] * self.ts #y
		self.position[2,0] = self.position[2,0] + x_dot[2,0] * self.ts #th
		#leveling
		heading = (self.position[2,0] * 4.71238 / 15.35) % (2*pi)
		x_pos = self.position[0,0] * 6.63 / 10.
		y_pos = self.position[1,0] * 9.5 / 14.6
		#update theta
		self.th = heading
		odom.x = x_pos #* 64.2857143 - 0.28571429
		odom.y = y_pos #* 60 - 0.8
		odom.z = heading * 180 / pi#* 20.5949657 - 28.421053
		#========================================================================
		pub.publish(odom)
		
if __name__ == "__main__":
	rospy.init_node("robot1_odometry_node")
	pub = rospy.Publisher("robot1/odometry", Vector3, queue_size=2)
	odom = Vector3()
	server = Server()
	try:
		rospy.Subscriber('/robot1/encoder', Vector3, server.get_encoder)
		rospy.Subscriber('/robot1/encoder_correction', Vector3, server.get_update)	
		rospy.spin()
	except rospy.ROSInterruptException:
		pass