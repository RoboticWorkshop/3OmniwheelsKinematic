#!/usr/bin/env python

import rospy
from numpy import *
from geometry_msgs.msg import Vector3
from std_msgs.msg import Float32
from std_msgs.msg import Int32

class Server:
	def __init__(self):
		self.error_val = 2
		self.tg = 0
		self.total_target = 3
		
	def e_norm(self, dat):
		self.error_val = dat.data
		self.target()

	def target(self):
		if(self.error_val < 0.05):
			self.tg = self.tg + 1
			if(self.tg > 2):
				self.tg = 0
			#if(self.tg < (self.total_target-1)):
			#	self.tg = self.tg + 1
		pos.data = self.tg
		pub.publish(pos)
		rospy.loginfo(pos)

if __name__ == "__main__":
	rospy.init_node('desired_position_node')
	pub = rospy.Publisher('target', Int32, queue_size = 10)
	pos = Int32()
	server = Server()
	delay = rospy.Rate(10)
	try:
		rospy.Subscriber("error", Float32, server.e_norm)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass