#!/usr/bin/env python

import rospy
from numpy import *
from geometry_msgs.msg import Vector3
from std_msgs.msg import Float32

if __name__ == "__main__":
	rospy.init_node('single_position_node')
	pub = rospy.Publisher('pos_desired', Vector3, queue_size = 10)
	pos = Vector3()
	pos.x = -2
	pos.y = 0
	theta = 0 % 360
	pos.z = theta * pi / 180
	delay = rospy.Rate(10)
	try:
		while not rospy.is_shutdown():
			pub.publish(pos)
			rospy.loginfo(pos)
			delay.sleep()
	except rospy.ROSInterruptException:
		pass

