#!/usr/bin/env python

import sympy as sp
from numpy import *
import matplotlib.pyplot as plt
from numpy.linalg import inv
import rospy
from geometry_msgs.msg import Vector3
from std_msgs.msg import Float32
from std_msgs.msg import Int32


class Server:
	def __init__(self):
		self.alp = array([[0*pi/180, 120*pi/180, 240*pi/180]]).T #robot specification
		self.l = 0.20		
		self.r = 0.05
		self.Jr = self.jacobianR()
		self.th = 0. * pi / 180.
		self.kp = 20 #20
		self.dest = array([[2., 2., 0.*pi/180.], [-2., 2., 90.*pi/180.], [0., 0., 270.*pi/180.]])
		self.x_des = sp.Matrix([[0., 0., 0.]]).transpose()
		self.x = sp.Matrix([[0, 0, 0]]).transpose()#koordinat actual
		self.target = 0
		self.enorm = 1
		self.max = 400
		

	def jacobianR(self):
		Js=array([[0.,0.,0.],[0.,0.,0.],[0.,0.,0.]])
		Js[0,0]=sp.cos(self.alp[0,0])
		Js[0,1]=sp.cos(self.alp[1,0])
		Js[0,2]=sp.cos(self.alp[2,0])
		Js[1,0]=sp.sin(self.alp[0,0])
		Js[1,1]=sp.sin(self.alp[1,0])
		Js[1,2]=sp.sin(self.alp[2,0])
		Js[2,0]=1./self.l
		Js[2,1]=1./self.l
		Js[2,2]=1./self.l
		#print(Jr)
		return self.r*Js

	def get_target(self, dat):
		self.target = dat.data

	def get_desired(self, dat):
		self.x_des[0, 0] = dat.x
		self.x_des[1, 0] = dat.y
		self.x_des[2, 0] = dat.z

	def jacobianW(self,th,Jr):
		rotZ = array([[sp.cos(th), -sp.sin(th), 0.], [sp.sin(th), sp.cos(th), 0.], [0., 0., 1]])
		#print(rotZ)
		Jw = rotZ.dot(Jr)
		return sp.Matrix(Jw)
	
	def get_odom(self, dat):
		self.x[0, 0] = dat.x #present x coordinate
		self.x[1, 0] = dat.y #present y coordinate
		self.x[2, 0] = dat.z * pi / 180. #present heading in radian
		self.th = self.x[2, 0]
		self.control()

	def control(self):
		er.data = self.enorm
		pub1.publish(er)
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#self.x_des[0, 0] = self.dest[self.target, 0]
		#self.x_des[1, 0] = self.dest[self.target, 1]
		#self.x_des[2, 0] = self.dest[self.target, 2]
		#desired 0 - 180
		if(self.x_des[2, 0] >= 0) and (self.x_des[2, 0] <= pi):
			self.Er = self.x_des - self.x	
			if(self.x[2,0] > pi) and (self.x[2,0] < 2*pi):
				self.Er[2,0] = self.Er[2,0] % (2*pi)	
		#desired 181 - 359
		elif(self.x_des[2, 0] > pi) and (self.x_des[2, 0] < 2*pi):
			self.Er = self.x_des - self.x	
			if(self.x[2,0] >= 0) and (self.x[2,0] < pi):
				self.Er[2,0] = self.Er[2,0] - (2*pi)
		if(self.Er.norm()<0.05):
			self.Er = self.Er * 0.
		#print self.Er
		#rospy.loginfo(er)
		#===================== compute w for motor =============================================
		w = self.kp*self.Jinv*self.Er
		if(w[0,0]>0.4) and (w[0,0]<125):
			w[0,0] = 125
		elif (w[0,0]<-0.4) and (w[0,0]>-125):
			w[0,0] = -125
		elif(w[0,0]>400):
			w[0,0] = 400
		elif (w[0,0]<-400):
			w[0,0] = -400
		
		if(w[1,0]>3) and (w[1,0]<150):
			w[1,0] = 150
		elif (w[1,0]<-3) and (w[1,0]>-150):
			w[1,0] = -150
		elif(w[1,0]>400):
			w[1,0] = 400
		elif (w[1,0]<-400):
			w[1,0] = -400
		
		if(w[2,0]>3) and (w[2,0]<150):
			w[2,0] = 100
		elif (w[2,0]<-3) and (w[2,0]>-150):
			w[2,0] = -150
		elif(w[2,0]>400):
			w[2,0] = 400
		elif (w[2,0]<-400):
			w[2,0] = -400
		self.enorm = self.Er.norm()
		print w
		if(self.enorm < 0.05):
			pwm.y = 0
			pwm.z = 0
			pwm.x = 0
			for i in range(10):
				pub.publish(pwm)
		else :
			pwm.y = w[0,0]
			pwm.z = w[1,0]
			pwm.x = w[2,0]
			pub.publish(pwm)
		print pwm
		#rospy.loginfo(pwm)
		#print w
		
if __name__ == "__main__":
	rospy.init_node("invers_kinematic_node")
	pub = rospy.Publisher("pwm_val", Vector3, queue_size=10)
	pub1 = rospy.Publisher("error", Float32, queue_size=10)
	pwm = Vector3()
	er = Float32()
	odom = Vector3()
	server = Server()
	try:
		#rospy.Subscriber('/target', Int32, server.get_target)
		rospy.Subscriber('/pos_desired', Vector3, server.get_desired)
		rospy.Subscriber('/odometry_fw', Vector3, server.get_odom)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass