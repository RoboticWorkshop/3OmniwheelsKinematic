#!/usr/bin/env python

import rospy
from numpy import *
from geometry_msgs.msg import Vector3
from std_msgs.msg import String
from std_msgs.msg import Int32
from std_msgs.msg import Float32
from std_msgs.msg import Int32MultiArray
from std_msgs.msg import Float32MultiArray

#target data:
 #0 = home position
 #1 = kick off attack
 #2 = kick off defend

class Server:
	def __init__(self):
		self.destination = array([[6., 0., 0.], [4., 4., 30.], [4., 2.75, 0.]])
		self.attack_pos = [[1.5, 7.5], [3.0, 7.5], [4.5, 7.5]]
		self.odom = array([[0., 0., 0.], [0., 0., 0.]])
		self.cmd = array([[0, 0]])
		print "node manager running"

	def odometry_fw(self, dat):#subscribe odometry robot fw
		self.odom[0,0] = dat.x
		self.odom[0,1] = dat.y
		self.odom[0,2] = dat.z
		self.command_skill()

	def odometry_cb(self, dat):#subscribe odometry robot cb
		self.odom[1,0] = dat.x
		self.odom[1,1] = dat.y
		self.odom[1,2] = dat.z		

	def command_input(self, dat):#input command from keyboard
		self.cmd[0,0] = dat.data[0]
		self.cmd[0,1] = dat.data[1]
		self.command_skill()

	def command_skill(self):#publish skill
		dat.data[0] = self.cmd[0,0]
		if(self.cmd[0,0] == 1):
			dat.data[1] = self.destination[self.cmd[0,1], 0]
			dat.data[2] = self.destination[self.cmd[0,1], 1]
			theta = self.destination[self.cmd[0,1], 2] * pi /180
			dat.data[3] = theta

		elif(self.cmd[0,0] == 2):
			if(self.cmd[0,1] == 11):
				dat.data[1] = 0 
				dat.data[2] = 2
				dat.data[3] = 0
			elif(self.cmd[0,1] == 12):
				dat.data[1] = 2 
				dat.data[2] = 0
				dat.data[3] = 0
			elif(self.cmd[0,1] == -11):
				dat.data[1] = 0 
				dat.data[2] = -2
				dat.data[3] = 0
			elif(self.cmd[0,1] == -12):
				dat.data[1] = -2 
				dat.data[2] = 0
				dat.data[3] = 0

		elif(self.cmd[0,0] == 4):
			if(self.cmd[0,1] == 15):
				dat.data[4] = 1
			elif(self.cmd[0,1] == 16):
				dat.data[4] = 2
		elif(self.cmd[0,0] == 5):
			if(self.cmd[0,1] == 17):
				dat.data[4] = 3
			elif(self.cmd[0,1] == 18):
				dat.data[4] = 4
		elif(self.cmd[0,0])
		pub_skill.publish(dat)
		
if __name__ == "__main__":
	rospy.init_node('robot1_manager_node')
	pub_skill = rospy.Publisher('robot1/skill', Float32MultiArray, queue_size = 10)
	server = Server()
	dat = Float32MultiArray()
	dat.data = [0, 0., 0., 0., 0., 0]
	try:
		rospy.Subscriber('robot1/odometry', Vector3, server.odometry_fw)
		rospy.Subscriber('robot2/odometry', Vector3, server.odometry_cb)
		rospy.Subscriber('base_station_command', Int32MultiArray, server.command_input)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass