#!/usr/bin/env python

import sympy as sp
from numpy import *
import matplotlib.pyplot as plt
from numpy.linalg import inv
import rospy
from geometry_msgs.msg import Vector3
from std_msgs.msg import Int32

class Server:
	def __init__(self):
		self.alp = array([[0*pi/180, 120*pi/180, 240*pi/180]]).T #robot specification
		self.lenc = [0,0,0]
		self.enc = [0,0,0]
		self.position = [0,0,0]
		self.ts = 0.1#0.0635
		self.th = 0*pi/180.
		self.l = 0.20		
		self.r = 0.05
		self.Jr = self.jacobianR()
		self.kp = 50		#lamda
		self.x_des = sp.Matrix([[0.,0.,0]]).transpose()
		self.x = sp.Matrix([[self.position[0], self.position[1], self.position[2]]]).transpose()#koordinat actual
		self.w_enc = array([[0.,0.,0.]]).T
		self.rot = -90.*pi/180.


	def get_encoder(self, dat):
		k = 3.956 * pi/180.
		#k = 1.
		self.enc[0] = dat.y*k#w1 y = belakang
		self.enc[1] = dat.z*k #w2 z = kanan
		self.enc[2] = dat.x*k #w3 x = kiri
		self.control()

	def get_desired(self, dat):	
		self.x_des[0,0] = dat.x
		self.x_des[1,0] = dat.y
		self.x_des[2,0] = dat.z

	def jacobianR(self):
		Js=array([[0.,0.,0.],[0.,0.,0.],[0.,0.,0.]])
		Js[0,0]=sp.cos(self.alp[0,0])
		Js[0,1]=sp.cos(self.alp[1,0])
		Js[0,2]=sp.cos(self.alp[2,0])
		Js[1,0]=sp.sin(self.alp[0,0])
		Js[1,1]=sp.sin(self.alp[1,0])
		Js[1,2]=sp.sin(self.alp[2,0])
		Js[2,0]=1./self.l
		Js[2,1]=1./self.l
		Js[2,2]=1./self.l
		#print(Jr)
		return self.r*Js

	def jacobianW(self,th,Jr):
		rotZ = array([[sp.cos(th), -sp.sin(th), 0.], [sp.sin(th), sp.cos(th), 0.], [0., 0., 1]])
		#print(rotZ)
		Jw = rotZ.dot(Jr)
		return sp.Matrix(Jw)

	def control(self):
		self.update_position()
		Er = self.x_des - self.x
		#compute jacobian
		J = self.jacobianW(self.th, self.Jr)
		Jinv = J.inv()
		#===================== compute w for motor =============================================
		w = self.kp*Jinv*Er
		pwm.y = w[0,0]
		pwm.z = w[1,0]
		pwm.x = w[2,0]
		pub1.publish(pwm)
		#print w

	def update_position(self):
		#compute error position
		#compute x dot
		#==================== position update from encoder =====================================
		self.w_enc[0,0] = self.enc[0]/self.ts#w1
		self.w_enc[1,0] = self.enc[1]/self.ts#w2
		self.w_enc[2,0] = self.enc[2]/self.ts#w3
		J = self.jacobianW(self.th, self.Jr)
		x_dot = sp.Matrix(J.dot(self.w_enc))
		#update position
		self.position[0] = self.position[0] + x_dot[0] * self.ts #x
		self.position[1] = self.position[1] + x_dot[1] * self.ts #y
		self.position[2] = self.position[2] + x_dot[2] * self.ts #th
		#leveling
		heading = (self.position[2] * 4.71238 / 15.35) % (2*pi)
		x_pos = self.position[0]
		y_pos = self.position[1]
		self.x[0,0] = x_pos
		self.x[1,0] = y_pos
		self.x[2,0] = heading
		#update theta
		self.th = self.x[2,0]
		odom.x = self.x[0,0] #* 64.2857143 - 0.28571429
		odom.y = self.x[1,0] #* 60 - 0.8
		odom.z = self.x[2,0] * 180 / pi#* 20.5949657 - 28.421053
		#========================================================================
		pub.publish(odom)
		
		
if __name__ == "__main__":
	rospy.init_node("position_updater")
	pub = rospy.Publisher("odometry_fw", Vector3, queue_size=10)
	pub1 = rospy.Publisher("pwm_val", Vector3, queue_size=10)
	pwm = Vector3()
	odom = Vector3()
	server = Server()
	try:
		rospy.Subscriber('/encoder_fw', Vector3, server.get_encoder)
		rospy.Subscriber('/pos_desired', Vector3, server.get_desired)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass