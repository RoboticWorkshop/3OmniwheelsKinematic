#!/usr/bin/env python

from __future__ import print_function

import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy

from std_msgs.msg import String
from std_msgs.msg import Int16

import sys, select, termios, tty

msg = """
Reading from the keyboard  and Publishing to Twist!
---------------------------
Moving around:
	q  w  e 
	a  s  d 
	   x   

kick the ball	   = f

ball kicking mode  = z
ball charging mode = x
anything else : stop

CTRL-C to quit
"""

moveBindings = {
		'W':("W"),
		'w':("w"), 
		'a':("a"),
		's':("s"),
		'd':("d"),
		'q':("q"),
		'e':("e"),
		'z':("z"),
		'x':("x"),
		}

kickBindings = {
		'f':("f"),
		'g':("g"),
		}

delayBindings = {
		'o':(1,0),
		'p':(-1,0),
		'y':(5,0),
		'u':(-5,0),
		}

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)

	pub = rospy.Publisher('robot_cmd', String, queue_size = 1)
	pub1 = rospy.Publisher('delay_kick', Int16, queue_size = 1)
	rospy.init_node('robsonema_teleop_node')
	command = String()
	delay = Int16()
	delay.data = 10
	try:
		print(msg)
		while(1):
			key = getKey()
			if key in moveBindings.keys():
				command.data = moveBindings[key][0]
			elif key in kickBindings.keys():
				command.data = kickBindings[key][0]
			elif key in delayBindings.keys():
				delay.data = delay.data + delayBindings[key][0]
				rospy.loginfo(delay)
				pub1.publish(delay)
			else:
				command.data = "s"
				if (key == '\x03'):
					break
			pub.publish(command)
		
	except Exception as e:
		print(e)

	finally:
		pub.publish(command)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


