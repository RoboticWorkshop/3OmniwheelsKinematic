#ifndef GERAKAN_H
#define GERAKAN_H

extern volatile byte address;

void run_program();

#endif
