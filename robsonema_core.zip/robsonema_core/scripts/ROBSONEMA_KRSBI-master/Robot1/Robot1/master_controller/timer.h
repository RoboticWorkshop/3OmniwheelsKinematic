#ifndef TIMER_H
#define TIMER_H

extern volatile bool update_enc;

void init_timer(int milsec);

#endif
