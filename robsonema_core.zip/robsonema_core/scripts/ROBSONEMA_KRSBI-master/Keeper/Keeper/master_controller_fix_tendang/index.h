#ifndef INDEX_H
#define INDEX_H

extern volatile bool strt;
extern volatile int adds;
extern volatile int lastsign;

void start_positioning();
void start_positioning1();
void mid_pos();
void run_program2();
void mid_kick();

#endif
