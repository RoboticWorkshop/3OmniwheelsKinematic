#!/usr/bin/env python

from __future__ import print_function

import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy
import numpy as np

from std_msgs.msg import Int32MultiArray, Int32
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import String

import sys, select, termios, tty

msg = """
Welcome to -- ROBSONEMA BASE STATION TELEOP KEY --
---------------------------
===== robot2 general command =====
s = Stop
a = Positioning kickoff attack
A = Positioning kickoff defense
d = Positioning goalkick attack
D = Positioning goalkick defense
e = Positioning corner attack
E = Positioning corner defense
q = Positioning Dropball 4 2 0
p = start

CTRL-C to quit
"""
#skill, position, info, goalkeeper command
moveBindings = {
		's':(0,0,0),
		'a':(2,0,0),
		'A':(2,0,1),
		'd':(2,2,0),
		'D':(2,2,1),
		'e':(2,4,0),
		'E':(2,4,1),
		'q':(2,10,0),
		't':(2,5,0),
		'p':(1,0,0),
		}

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)

	rospy.init_node('dummy_reff_box_node')
	pub = rospy.Publisher('base_station_command', Int32MultiArray, queue_size = 10)
	command = Int32MultiArray()
	command.data = [0,0,0]
	try:
		print(msg)
		while(1):
			key = getKey()
			if key in moveBindings.keys():
				head = moveBindings[key][0]
				cod = moveBindings[key][1]
				od = moveBindings[key][2]
		
			else:
				head = 0
				cod = 0
				od = 0
				if (key == '\x03'):
					break	
			command.data[0] = head #stop, start, positioning
			command.data[1] = cod #kickoff, goalkick, etc
			command.data[2] = od #offense / defense
			pub.publish(command)
			#pub1.publish(1)
		
	except Exception as e:
		print(e)

	finally:
		head = 0
		cod = 0
		od = 0
		command.data[0] = head #stop, start, positioning
		command.data[1] = cod #kickoff, goalkick, etc
		command.data[2] = od #offense / defense
		pub.publish(command)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
