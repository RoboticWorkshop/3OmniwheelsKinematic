#!/usr/bin/env python

from __future__ import print_function

import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy
import numpy as np

from std_msgs.msg import Int32MultiArray
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import String

import sys, select, termios, tty

msg = """
Welcome to -- ROBSONEMA BASE STATION TELEOP KEY --
---------------------------
===== general command =====
S = Stop robot
s = goto 0 0 0
a = goto 0 0 90
d = goto 0 0 -90
q = goto 0 3 0
e = goto 5 3 0
z = goto 5 3 90 
x = goto 5 3 180
c = goto 5 3 -90
p = visual servoing

CTRL-C to quit
"""
#skill, position, info, goalkeeper command
moveBindings = {
		'S':(0.,0.,0.,0.,0),
		'a':(2.,0.,0.,90,0),
		'd':(2.,0.,0.,-90,0),
		's':(2.,0.,0.,0.,0),
		'q':(2.,8.,3.,0.,0),
		'e':(2.,5.,3.,0.,0),
		'z':(2.,5.,3.,90.,0),
		'x':(2.,5.,3.,180.,0),
		'c':(2.,5.,3.,-90.,0),
		'p':(1.,0.,0.,0.,0),
		}

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)

	rospy.init_node('taliop_node')
	pub = rospy.Publisher('robot1/skill', Float32MultiArray, queue_size = 2)
	command = Float32MultiArray()
	note = String()
	command.data = [0,0,0,0,0]
	try:
		print(msg)
		while(1):
			key = getKey()
			if key in moveBindings.keys():
				skill = moveBindings[key][0]
				x = moveBindings[key][1]
				y = moveBindings[key][2]
				th = moveBindings[key][3]
				df = moveBindings[key][4]
			else:
				skill = 0
				x = 0
				y = 0
				th = 0
				df = 0
				if (key == '\x03'):
					break
			if(skill == 20):
				print(msg)
			else:
				command.data[0] = skill
				command.data[1] = x
				command.data[2] = y
				command.data[3] = th*np.pi/180.
				command.data[4] = df
			pub.publish(command)
		
	except Exception as e:
		print(e)

	finally:
		pub.publish(command)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


