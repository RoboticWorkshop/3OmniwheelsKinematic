#!/usr/bin/env python
#kinematic control robot2
import sympy as sp
import numpy as np
from numpy import *
import matplotlib.pyplot as plt
from numpy.linalg import inv
import rospy
import random as rd
from geometry_msgs.msg import Vector3, PoseWithCovarianceStamped
from std_msgs.msg import Float32
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import Int32


class Server:
	def __init__(self):
		#==================================================================================================
		#variabel kinematik
		self.alp = array([[0*pi/180, 120*pi/180, 240*pi/180]]).T #robot specification
		self.l = 0.20 #panjang posisi roda robot dari titik tengah robot
		self.r = 0.05 #besar jari - jari roda robot
		self.Jr = self.jacobianR()
		self.th = 0. * pi / 180. #nilai heading awal robot
		self.x_des = sp.Matrix([[0., 0., 0.]]).transpose()#koordinat tujuan (dari node manager)
		self.x = sp.Matrix([[0, 0, 0]]).transpose()#koordinat aktual
		self.last_pose = sp.Matrix([[0, 0, 0]]).transpose()
		self.lamda_ball = sp.Matrix([[30., 0., 0.], [0., 40., 0.], [0., 0., 55.]])
		self.lamda = sp.Matrix([[35., 0., 0.], [0., 45., 0.], [0., 0., 65.]])
		#self.lamda = sp.Matrix([[25., 0., 0.], [0., 30., 0.], [0., 0., 35.]])
		self.lamda_pos = sp.Matrix([[35., 0., 0.], [0., 35., 0.], [0., 0., 35.]])
		self.lamda_obs = sp.Matrix([[15., 0., 0.], [0., 15., 0.], [0., 0., 15.]])
		self.kp_temp = 0.
		self.x_standby = sp.Matrix([[-4.0, -0.5, 0.]]).transpose()
		self.x_quadrant = sp.Matrix([[0., 0., 0.]]).transpose()
		#=======================================================================================
		#variabel visual servoing
		self.cam     = sp.Matrix([[0., 0., 0.]]).transpose()
		self.cam_des = sp.Matrix([[0., 0.35, 0.]]).transpose()
		self.get_ball = 0
		#=========================================================================================
		#variabel lainnya
		self.skill = 0 #mode yang dikirimkan oleh node manager (0:stop, 1:visual servoing, 2: positioning)
		self.last_skill = 0 #mode yang dikirimkan oleh node manager (0:stop, 1:visual servoing, 2: positioning)
		self.ball = 0 #index bola
		self.ball1 = 0 #index bola di robot teman
		self.detik = 0 #waktu untuk akselerasi
		self.kick = 0 #index tendang pelan dan tendang keras
		self.rot_mat = sp.Matrix([[sp.cos(0.5*pi), -sp.sin(0.5*pi), 0.],[sp.sin(0.5*pi), sp.cos(0.5*pi), 0.], [0., 0., 1.]])
		self.index_complete = 0
		self.index_lock_complete = 0
		self.limit_pwm = 500
		self.limit_pwm_pos = 400
		self.threshold_pos_error = 0.2
		self.amcl_update = 0
		self.pose_update_position = sp.Matrix([[-5., -3.5, 0.]]).transpose()
		self.goal_pos = np.matrix([[6.0, 0.]], dtype='float').transpose()
		self.additional_list = [-1.0 ,-0.75, -0.5, 0.0, 0.5, 0.75, 1.0]#x
		self.additional_list1 = [-1.0, -0.75, -0.5, -0.25, 0.0, 0.25, 0.5, 0.75, 1.0]#y
		self.dummy_target_x = 0
		self.dummy_target_y = 0
		self.strategy = 0
		self.skill = 0
		self.counter = 0
		
	def jacobianR(self): #jacobian robot
		Js=array([[0.,0.,0.],[0.,0.,0.],[0.,0.,0.]])
		Js[0,0]=sp.cos(self.alp[0,0])
		Js[0,1]=sp.cos(self.alp[1,0])
		Js[0,2]=sp.cos(self.alp[2,0])
		Js[1,0]=sp.sin(self.alp[0,0])
		Js[1,1]=sp.sin(self.alp[1,0])
		Js[1,2]=sp.sin(self.alp[2,0])
		Js[2,0]=1./self.l
		Js[2,1]=1./self.l
		Js[2,2]=1./self.l
		#print(Jr)
		return self.r*Js
	
	def jacobianW(self,th,Jr): #jacobian robot terhadap lapangan
		rotZ = array([[sp.cos(th), -sp.sin(th), 0.], [sp.sin(th), sp.cos(th), 0.], [0., 0., 1]])
		Jw = rotZ.dot(Jr)
		return sp.Matrix(Jw)
		
	def get_odom(self, dat):
		self.x[0, 0] = dat.x #present x coordinate
		self.x[1, 0] = dat.y #present y coordinate
		self.x[2, 0] = dat.z #present heading in radian
		self.th = self.x[2, 0]
		self.main()

	def get_skill(self, dat):
		self.skill = dat.data[0] #mode gerakan
		self.x_des[0, 0] = dat.data[1] #x tujuan
		self.x_des[1, 0] = dat.data[2] #y tujuan
		self.x_des[2, 0] = dat.data[3] #theta tujuan
		self.index_serang = dat.data[4] #posisi defend atau attack
		if(self.skill == 0):
			if(self.last_skill != 0):
				force_update.publish(1)
				print "Update While Stop"
		self.index_lock_complete = 0
		self.last_skill = self.skill
		
	def get_camera(self, dat):#subscribe data bola dari kamera
		self.cam[0,0] = dat.x
		self.cam[1,0] = dat.y
		self.cam[2,0] = dat.z
		self.main()
	
	def get_ball_info(self, dat):#subscribe posisi bola
		self.ball = dat.data
		if(self.ball == 1):
			self.last_pose[0,0] = self.x[0, 0]#present y coordinate
			self.last_pose[1,0] = self.x[1, 0]
			#self.dummy_target_x = self.additional_list[rd.randint(0, 5)]
			#self.dummy_target_y = self.additional_list1[rd.randint(0, 8)]
			self.dummy_target_x = self.x[0,0]
			self.dummy_target_y = self.x[1,0]
			#kick_position.x = self.dummy_target_x
			#kick_position.y = self.dummy_target_y
			kick_position.x = self.x[0,0]
			kick_position.y = self.x[1,0]
			kick_position.z = 0
			robot2_kick_pos_pub.publish(kick_position) 
	
	def get_ball_info2(self, dat):#subscribe posisi bola teman
		self.ball1 = dat.data

	def get_strategy(self, dat):
		self.strategy = dat.data
	
	def get_quadrant_des(self, dat):
		self.x_quadrant[0,0] = dat.x
		self.x_quadrant[1,0] = dat.y
		self.x_quadrant[2,0] = dat.z
		#print "quadrant target = ", self.x_quadrant
	
	def pwm_leveling(self, w):
		temp = np.array([abs(w[0,0]), abs(w[1,0]), abs(w[2,0])])
		out = sp.Matrix([[0., 0., 0.]]).transpose()
		maximum = np.max(temp)
		if(maximum > self.limit_pwm):
			out[0,0] = (w[0,0]/maximum)*self.limit_pwm
			out[1,0] = (w[1,0]/maximum)*self.limit_pwm
			out[2,0] = (w[2,0]/maximum)*self.limit_pwm
		else:
			out[0,0] = w[0,0]
			out[1,0] = w[1,0]
			out[2,0] = w[2,0]
		#====================== W1 ====================
		if(out[0,0]>0.4) and (out[0,0]<125):
			out[0,0] = 125
		elif (out[0,0]<-0.4) and (out[0,0]>-125):
			out[0,0] = -125
		#====================== W2 ====================
		if(out[1,0]>0.4) and (out[1,0]<125):
			out[1,0] = 125
		elif (w[1,0]<-0.4) and (out[1,0]>-125):
			out[1,0] = -125
		#====================== W3 ====================
		if(out[2,0]>0.4) and (out[2,0]<125):
			out[2,0] = 125
		elif (out[2,0]<-0.4) and (out[2,0]>-125):
			out[2,0] = -125
		#==============================================
		pwm.y = out[0,0] #belakang
		pwm.z = out[1,0] #kanan
		pwm.x = out[2,0] #kiri
		pwm_pub.publish(pwm)
		#print(pwm)
		
	def pwm_leveling_pos(self, w):
		temp = np.array([abs(w[0,0]), abs(w[1,0]), abs(w[2,0])])
		out = sp.Matrix([[0., 0., 0.]]).transpose()
		maximum = np.max(temp)
		if(maximum > self.limit_pwm_pos):
			out[0,0] = (w[0,0]/maximum)*self.limit_pwm_pos
			out[1,0] = (w[1,0]/maximum)*self.limit_pwm_pos
			out[2,0] = (w[2,0]/maximum)*self.limit_pwm_pos
		else:
			out[0,0] = w[0,0]
			out[1,0] = w[1,0]
			out[2,0] = w[2,0]
		#====================== W1 ====================
		if(out[0,0]>0.4) and (out[0,0]<125):
			out[0,0] = 125
		elif (out[0,0]<-0.4) and (out[0,0]>-125):
			out[0,0] = -125
		#====================== W2 ====================
		if(out[1,0]>0.4) and (out[1,0]<125):
			out[1,0] = 125
		elif (w[1,0]<-0.4) and (out[1,0]>-125):
			out[1,0] = -125
		#====================== W3 ====================
		if(out[2,0]>0.4) and (out[2,0]<125):
			out[2,0] = 125
		elif (out[2,0]<-0.4) and (out[2,0]>-125):
			out[2,0] = -125
		#==============================================
		pwm.y = out[0,0] #belakang
		pwm.z = out[1,0] #kanan
		pwm.x = out[2,0] #kiri
		pwm_pub.publish(pwm)
	
	def visual_servoing(self):#fungsi gerakan mendekati bola
		vJinv = sp.Matrix(self.Jr).inv()#invers jacobian
		self.Er = self.cam - self.cam_des 
		w = self.kp*vJinv*self.Er
		if(self.Er.norm()<0.2):
			print "visual servoing approached"
			self.get_ball = 1
			self.detik = 0
		else:
			self.detik = self.detik + 1
		self.pwm_leveling(w)
	
	def take_ball(self):
		if(self.cam[0,0]<0.04) and (self.cam[0,0]>-0.04):
			if(self.cam[1,0]>0.6):
				pwm.y = 0
				pwm.z = 420
				pwm.x = -430
			else:
				pwm.y = 0
				pwm.z = 300
				pwm.x = -325
		elif(self.cam[0,0]>0.04):
			if(self.cam[1,0]>0.6):
				pwm.y = 0
				pwm.z = 300
				pwm.x = -450
			else:
				pwm.y = 0
				pwm.z = 150
				pwm.x = -400
		elif(self.cam[0,0]<-0.04):
			if(self.cam[1,0]>0.6):
				pwm.y = 0
				pwm.z = 450
				pwm.x = -300
			else:
				pwm.y = 0
				pwm.z = 300
				pwm.x = -150
		pwm_pub.publish(pwm)
	
	def take_ball_penalty(self):
		if(self.cam[0,0]<0.04) and (self.cam[0,0]>-0.04):
			if(self.cam[1,0]>0.6):
				pwm.y = 0
				pwm.z = 320
				pwm.x = -330
			else:
				pwm.y = 0
				pwm.z = 200
				pwm.x = -225
		elif(self.cam[0,0]>0.04):
			if(self.cam[1,0]>0.6):
				pwm.y = 0
				pwm.z = 200
				pwm.x = -350
			else:
				pwm.y = 0
				pwm.z = 150
				pwm.x = -400
		elif(self.cam[0,0]<-0.04):
			if(self.cam[1,0]>0.6):
				pwm.y = 0
				pwm.z = 350
				pwm.x = -200
			else:
				pwm.y = 0
				pwm.z = 300
				pwm.x = -150
		pwm_pub.publish(pwm)	
			
	def control(self):#fungsi untuk positioning
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#==================== compute error ==================================
		self.Er = self.x_des - self.x
		#self.Er[1,0] = 0
		#self.Er[2,0] = 0
		if(self.Er.norm()<self.threshold_pos_error):
			self.Er = self.Er * 0.
			self.detik = 0
			self.index_complete = 1
			print "Target Reached"
			if(self.index_lock_complete == 0):
				complete_pub.publish(self.index_complete)
				self.index_lock_complete = 1
		else:
			self.index_complete = 0
			self.detik = self.detik + 1
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*(self.rot_mat*self.Er)
		#print "Run Control 1"
		self.pwm_leveling_pos(w)
	
	def control1(self):#fungsi untuk positioning
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#==================== compute error ==================================
		self.Er = self.pose_update_position - self.x
		if(self.Er.norm()<self.threshold_pos_error):
			new_amcl.pose.pose.position.x = self.pose_update_position[0,0]
			new_amcl.pose.pose.position.y = self.pose_update_position[1,0]
			new_amcl.pose.pose.position.z = 0.
			new_amcl.pose.pose.orientation.x = 0.
			new_amcl.pose.pose.orientation.y = 0.
			new_amcl.pose.pose.orientation.z = 0.0051
			new_amcl.pose.pose.orientation.w = 0.99
			new_amcl.pose.covariance[0] = 0.25
			new_amcl.pose.covariance[7] = 0.25
			new_amcl.pose.covariance[35] = 0.068
			amcl_pub.publish(new_amcl)
			self.Er = self.Er * 0.
			self.detik = 0
			self.amcl_update = 1
		else:
			self.index_complete = 0
			self.detik = self.detik + 1
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*(self.rot_mat*self.Er)
		#print "Go to AMCL update Position"
		self.pwm_leveling_pos(w)
	
	def quadrant_control(self):#fungsi untuk positioning
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		print self.x_quadrant
		#==================== compute error ==================================
		self.Er = self.x_quadrant - self.x
		if(self.Er.norm()<self.threshold_pos_error):
			self.Er = self.Er * 0.
			self.detik = 0
			self.index_complete = 1
			if(self.index_lock_complete == 0):
				complete_pub.publish(self.index_complete)
				self.index_lock_complete = 1
			print "Robot2 Quadrant Position Reached"
		else:
			self.index_complete = 0
			self.detik = self.detik + 1
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*(self.rot_mat*self.Er)
		#print "Go to quadran"
		self.pwm_leveling_pos(w)
	
	def defend_control(self):#fungsi untuk positioning
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#==================== compute error ==================================
		self.Er = self.x_standby - self.x
		if(self.Er.norm()<self.threshold_pos_error):
			self.Er = self.Er * 0.
			self.detik = 0
			self.index_complete = 1
			if(self.index_lock_complete == 0):
				complete_pub.publish(self.index_complete)
				self.index_lock_complete = 1
			robot2_dribbler_pub.publish(0)
			print "Robot2 Defend Position Reached"
		else:
			self.index_complete = 0
			self.detik = self.detik + 1
			robot2_dribbler_pub.publish(1)
			print "Robot2 Go To Defend Position"
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*(self.rot_mat*self.Er)
		#print "Go to defend Position"
		self.pwm_leveling_pos(w)	

	def go_to_target(self):
		p = matrix([[self.dummy_target_x, self.dummy_target_y]], dtype='float').transpose()
		tj = self.goal_pos - p
		alfa = arctan2(tj[1,0], tj[0,0])
		target = sp.Matrix([[self.dummy_target_x, self.dummy_target_y, alfa]]).transpose()
		print target
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#==================== compute error ==================================
		self.Er = target - self.x
		if(self.Er.norm()<0.1):
			self.Er = self.Er * 0.
			self.detik = 0
			tendang.data = 2
			kicker_pub.publish(tendang)
			print "ROBOT 2 KICK BALL!!!"
			self.index_complete = 1
			if(self.index_lock_complete == 0):
				complete_pub.publish(self.index_complete)
				self.index_lock_complete = 1
		else:
			self.detik = self.detik + 1
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*(self.rot_mat*self.Er)
		self.pwm_leveling(w)
	
	def penalty(self):
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		target = sp.Matrix([[0., 0., 0.]]).transpose()
		#==================== compute error ==================================
		self.Er = target - self.x
		self.Er[0,0] = 0
		self.Er[1,0] = 0
		if(self.Er.norm()<0.1):
			self.Er = self.Er * 0.
			self.detik = 0
			tendang.data = 2
			kicker_pub.publish(tendang)
			print "ROBOT 2 KICK BALL!!!"
		else:
			self.detik = self.detik + 1
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*(self.rot_mat*self.Er)
		self.pwm_leveling(w)		
	
	def main(self):
		#print self.skill
		if(self.skill == 0):#command stop
			pwm.y = 0
			pwm.z = 0
			pwm.x = 0
			robot2_dribbler_pub.publish(0)
			pwm_pub.publish(pwm)
			print "ROBOT2 STOP"

		elif(self.skill == 1):#command ball_finder
			#=========akselerasi================
			if(self.get_ball == 0):
				self.kp_temp = self.lamda_ball
			else:
				self.kp_temp = self.lamda
			if(self.detik < 10):
				self.kp = self.kp_temp*0.5
			elif(self.detik < 20):
				self.kp = self.kp_temp*0.75
			else:
				self.kp = self.kp_temp
			#===================================
			#self.go_to_target()

			if(self.ball1 == 1):#jika bola dipegang teman
				robot2_dribbler_pub.publish(0)
				self.defend_control()
			
			elif(self.ball == 1):
				if(self.index_lock_complete == 0):
					force_update.publish(1)
					self.index_lock_complete = 1
				if(self.strategy == 4):
					self.penalty()
				else:
					self.go_to_target()
			
			elif(self.strategy == 1):
				robot2_dribbler_pub.publish(0)
				self.defend_control()
			
			elif(self.ball == 0):
				self.index_lock_complete = 0
				if(self.cam[1,0]==0):
					if(self.strategy == 3) and (self.counter > 10):
						self.defend_control()
						print "Robot2 Go to Defend Position"
					else:
						pwm.y = 0
						pwm.z = 0
						pwm.x = 0
						force_update.publish(1)
						pwm_pub.publish(pwm)
						self.counter = self.counter + 1
						print self.counter
				elif(self.get_ball == 0):
					self.visual_servoing()
					self.counter = 0
					robot2_dribbler_pub.publish(0)
				elif(self.get_ball == 1):
					if(self.strategy == 4):
						self.take_ball()
					else:
						self.take_ball_penalty()
					robot2_dribbler_pub.publish(1)
					self.counter = 0
				else:
					pwm.y = 0
					pwm.z = 0
					pwm.x = 0
					pwm_pub.publish(pwm)					
				if(self.cam[1,0] > 1.4):
					self.get_ball = 0
					self.detik=0
				elif(self.cam[2,0] < -0.5) or (self.cam[2,0] > 0.5):
					self.get_ball = 0
					self.detik=0
				else:
					self.get_ball = 1
				#print "Print Robot2 Finding The Ball"
				print "Get Ball", self.get_ball
					
			#print "Robot Go to Position"
			#self.go_to_target()
						
		elif(self.skill == 2):#command position
			if(self.detik < 20):
				self.kp = self.lamda_pos*0.75
			else:
				self.kp = self.lamda_pos
			if(self.amcl_update == 0):
				self.control1()
			else:
				self.control()
			#self.control()
			#print "ROBOT POSITIONING"
		
		elif(self.skill == 3):
			#=========akselerasi================
			if(self.get_ball == 0):
				self.kp_temp = self.lamda_ball
			else:
				self.kp_temp = self.lamda
			if(self.detik < 10):
				self.kp = self.kp_temp*0.5
			elif(self.detik < 20):
				self.kp = self.kp_temp*0.75
			else:
				self.kp = self.kp_temp
			#===================================
			if(self.ball == 0):
				self.index_lock_complete = 0
				if(self.cam[1,0]==0):
					pwm.y = 0
					pwm.z = 0
					pwm.x = 0
					pwm_pub.publish(pwm)
				elif(self.get_ball == 0):
					self.visual_servoing()
					robot2_dribbler_pub(0)
				elif(self.get_ball == 1):
					self.take_ball()
				else:
					pwm.y = 0
					pwm.z = 0
					pwm.x = 0
					pwm_pub.publish(pwm)					
				if(self.cam[1,0] > 1.4):
					self.get_ball = 0
					self.detik=0
				elif(self.cam[2,0] < -0.5) or (self.cam[2,0] > 0.5):
					self.get_ball = 0
					self.detik=0
				else:
					self.get_ball = 1
			else:
				pwm.y = 0
				pwm.z = 0
				pwm.x = 0
				pwm_pub.publish(pwm)
				print "ROBOT GET THE BALL"
			#print self.get_ball
		
		elif(self.skill == 4):#command reset robot status
			new_amcl.pose.pose.position.x = self.pose_update_position[0,0]
			new_amcl.pose.pose.position.y = self.pose_update_position[1,0]
			new_amcl.pose.pose.position.z = 0.
			new_amcl.pose.pose.orientation.x = 0.
			new_amcl.pose.pose.orientation.y = 0.
			new_amcl.pose.pose.orientation.z = 0.0051
			new_amcl.pose.pose.orientation.w = 0.99
			new_amcl.pose.covariance[0] = 0.25
			new_amcl.pose.covariance[7] = 0.25
			new_amcl.pose.covariance[35] = 0.068
			amcl_pub.publish(new_amcl)
			pwm.y = 0
			pwm.z = 0
			pwm.x = 0
			self.amcl_update = 0
			pwm_pub.publish(pwm)
			print "ROBOT2 RESTART"
	
if __name__ == "__main__":
	rospy.init_node("robot2_kinematic_node")
	pwm_pub = rospy.Publisher("robot2/pwm_val", Vector3, queue_size=2)
	kicker_pub = rospy.Publisher("robot2/kick_ball", Int32, queue_size=1)
	complete_pub = rospy.Publisher("robot2/command_clear", Int32, queue_size=1)
	force_update = rospy.Publisher("robot2/force_update", Int32, queue_size=1)
	amcl_pub = rospy.Publisher("/robot2/initialpose", PoseWithCovarianceStamped, queue_size=10)
	robot2_dribbler_pub = rospy.Publisher('robot2/dribbler', Int32, queue_size = 1)
	robot2_kick_pos_pub = rospy.Publisher('robot2/kick_location', Vector3, queue_size = 1)
	pwm = Vector3()
	kick_position = Vector3()
	tendang = Int32()
	new_amcl = PoseWithCovarianceStamped()
	server = Server()
	try:
		rospy.Subscriber('robot2/skill', Float32MultiArray, server.get_skill)#perintah yang masuk dari node manager
		rospy.Subscriber('robot2/odometry', Vector3, server.get_odom)
		rospy.Subscriber('robot2/quadrant_des', Vector3, server.get_quadrant_des)
		rospy.Subscriber('robot2/camera', Vector3, server.get_camera)
		rospy.Subscriber('robot2/ball_position', Int32, server.get_ball_info)
		rospy.Subscriber('robot1/ball_position', Int32, server.get_ball_info2)
		rospy.Subscriber('node_manager/strategy', Int32, server.get_strategy)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass
