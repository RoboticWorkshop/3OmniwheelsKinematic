#!/usr/bin/env python

from __future__ import print_function

import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy
import numpy as np

from std_msgs.msg import Int32MultiArray, Int32
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import String

import sys, select, termios, tty

msg = """
Welcome to -- ROBSONEMA BASE STATION TELEOP KEY --
---------------------------
===== robot2 general command =====
S = Stop robot
s = home 0 0 0
a = kickoff 5 3 0 attack
A = kickoff 3 3 0 defend
d = goalkick 1 1 0 attack
D = goalkick 6 4 0 defend
e = corner 8 3 -30 attack
E = corner 3 3 -120 defend
q = Dropball 4 2 0 attack
Q = Dropball 4 2 0 defend
p = visual servoing

CTRL-C to quit
"""
#skill, position, info, goalkeeper command
moveBindings = {
		'S':(0.,0.,0.,0., 0),
		's':(2.,0.,0.,0., 0),
		'a':(2.,0.,-2.0, 90., 0),
		'A':(2.,-3.,-1.5,0., 1),
		'p':(1.,0., 0., 0., 1),
		'z':(3.,0.,0.,0., 0),
		#'d':(2.,1.,1.,0., 0),
		#'D':(2.,6.,4.,0., 1),
		#'e':(2.,8.,3.,-30., 0),
		#'E':(2.,3.,3.,-120., 1),
		#'q':(2.,4.,2.,0., 0),
		#'Q':(2.,4.,2.,0., 0),
		#'t':(2.,2.,0.,0.,0),
		#'p':(1.,0.,0.,0., 0),
		#'l':(2.,0.,0.,-90.,0),
		#'k':(2.,0.,0.,90., 0),
		}

dribBindings = {
		'm':(1.,0.),
		'M':(0.,0.),
		}

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)

	rospy.init_node('base_station_teleop_node')
	pub = rospy.Publisher('robot2/skill', Float32MultiArray, queue_size = 2)
	pub1 = rospy.Publisher('robot2/dribbler', Int32, queue_size = 1)
	command = Float32MultiArray()
	note = String()
	command.data = [0,0,0,0,0]
	dribbler = 0.
	try:
		print(msg)
		while(1):
			key = getKey()
			if key in moveBindings.keys():
				skill = moveBindings[key][0]
				x = moveBindings[key][1]
				y = moveBindings[key][2]
				th = moveBindings[key][3]
				df = moveBindings[key][4]
				command.data[0] = skill
				command.data[1] = x
				command.data[2] = y
				command.data[3] = th*np.pi/180.
				command.data[4] = df
				if(skill == 1) or (skill == 3):
					dribbler = 1
				else:
					dribbler = 0
				pub.publish(command)
				print(command)
			elif key in dribBindings.keys():
				dribbler = dribBindings[key][0]
			else:
				skill = 0
				x = 0
				y = 0
				th = 0
				df = 0
				if (key == '\x03'):
					break	
			if(dribbler == 1):
				print("Dribbler On")
			else:
				print("Dribbler Off")
			pub1.publish(dribbler)
		
	except Exception as e:
		print(e)

	finally:
		pub.publish(command)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
