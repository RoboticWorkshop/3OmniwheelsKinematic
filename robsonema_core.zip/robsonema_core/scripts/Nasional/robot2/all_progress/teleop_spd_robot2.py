#!/usr/bin/env python

from __future__ import print_function

import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy
import numpy as np

from geometry_msgs.msg import Vector3

import sys, select, termios, tty

msg = """
Welcome to -- ROBSONEMA BASE STATION TELEOP KEY --
---------------------------
===== move =====
	q	w	e
	
	a	s	d
	
	z	x	c

===== speed =====
o = -5
p = +5
k = -1
l = +1

CTRL-C to quit
"""
#skill, position, info, goalkeeper command
moveBindings = {
		's':(0,0,0),
		'w':(-1,0,1),
		'a':(0.5,0.5,0.5),
		'd':(-0.5,-0.5,-0.5),
		'x':(1,0,-1),
		'q':(-0.5,0,1),
		'e':(-1,0,0.5),
		'z':(1,-2,1),
		'c':(-1,2,-1),		
		}

speedBindings = {
		'o':(-5,0),
		'p':(5,0),
		'k':(-1,0),
		'l':(1,0),
		}

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)

	rospy.init_node('robot2_teleop_node')
	pub = rospy.Publisher("robot2/pwm_val", Vector3, queue_size=10)
	speed = Vector3()
	spd = 175
	try:
		print(msg)
		print(spd)
		while(1):
			key = getKey()
			if key in moveBindings.keys():
				speed.y = moveBindings[key][1]*spd #tengah
				speed.z = moveBindings[key][2]*spd #kanan
				speed.x = moveBindings[key][0]*spd #kiri
				for i in range(0,2):
					pub.publish(speed)
			elif key in speedBindings.keys():
				spd = spd + speedBindings[key][0]
				print(spd)
			else:
				speed.y = 0#tengah
				speed.z = 0 #kanan
				speed.x = 0 #kiri
				for i in range(0,2):
					pub.publish(speed)
				if (key == '\x03'):
					break
		
	except Exception as e:
		print(e)

	finally:
		pub.publish(speed)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


