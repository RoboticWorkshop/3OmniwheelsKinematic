#!/usr/bin/env python

from numpy import *
import random as rd

x = array([[3., 4., 27.*pi/180.]]).T
p = matrix([[rd.uniform(5,10), rd.uniform(2.5,5.5)]], dtype='float').transpose()
p_des = matrix([[12., 4.]], dtype='float').transpose()
R_t = matrix([[cos(x[2,0]), sin(x[2,0])], [sin(x[2,0]), cos(x[2,0])]], dtype='float')
R_ti = linalg.inv(R_t)
tj = R_ti * (p_des - p)
alp = arctan2(tj[1,0], tj[0,0])
alp = alp + x[2,0]
x_des = matrix([[p[0,0], p[1,0], alp]]).transpose()

print x_des
