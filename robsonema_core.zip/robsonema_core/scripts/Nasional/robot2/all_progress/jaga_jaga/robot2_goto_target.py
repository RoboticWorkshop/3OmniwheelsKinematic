#!/usr/bin/env python
#kinematic control robot1
import sympy as sp
import numpy as np
from numpy import *
import matplotlib.pyplot as plt
from numpy.linalg import inv
import rospy
import random as rd
from geometry_msgs.msg import Vector3
from std_msgs.msg import Int32


class Server:
	def __init__(self):
		self.current_time = rospy.Time.now()
		self.last_time = 0
	
	def get_pose(self, dat):
		self.current_time = rospy.get_time()
		times = float(self.current_time)
		secs = times - self.last_time
		if(secs > 2):
			print secs
			self.last_time = times
			
	
if __name__ == "__main__":
	rospy.init_node("robot2_kinematic_node")
	server = Server()
	try:
		rospy.Subscriber('/robot2/camera', Vector3,server.get_pose)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass
