#!/usr/bin/env python

import rospy
from numpy import *
from geometry_msgs.msg import Vector3
from sensor_msgs.msg import Joy

class Server:
	def __init__(self):
		self.analog = array([0., 0., 0., 0.]) #leftX, leftY, rightX, rightY
		self.button = array([0., 0., 0., 0.]) #A, B, X, Y
		self.tb_start = 0
		self.pwm_val = 200
		self.pwm_val1 = 250
		print self.pwm_val
		print self.pwm_val1

	def read_joy(self, dat):
		self.analog[0] = dat.axes[0]
		self.analog[1] = dat.axes[1]
		self.analog[2] = dat.axes[3]
		self.analog[3] = dat.axes[4]
		self.button[0] = dat.buttons[0]
		self.button[1] = dat.buttons[1]
		self.button[2] = dat.buttons[2]
		self.button[3] = dat.buttons[3]
		self.tb_start = dat.buttons[7]
		#print self.button
		#print self.analog
		self.convert_2_pwm()
	
	def convert_2_pwm(self):
		if(self.analog[1] == 1):
			if(self.analog[0] == 1):
				pwm.y = 0*self.pwm_val#belakang
				pwm.z = self.pwm_val#kanan
				pwm.x = -0.5*self.pwm_val#kiri
			elif(self.analog[0] == -1):
				pwm.y = 0*self.pwm_val#belakang
				pwm.z = 0.5*self.pwm_val#kanan
				pwm.x = -1*self.pwm_val#kiri
			else:
				pwm.y = 0*self.pwm_val#belakang
				pwm.z = 1*self.pwm_val#kanan
				pwm.x = -1*self.pwm_val#kiri
				
		elif(self.analog[1] == 0):
			if(self.analog[0] == 1):
				pwm.y = 0.5*self.pwm_val1#belakang
				pwm.z = 0.5*self.pwm_val1#kanan
				pwm.x = 0.5*self.pwm_val1#kiri
			elif(self.analog[0] == -1):
				pwm.y = -0.5*self.pwm_val1#belakang
				pwm.z = -0.5*self.pwm_val1#kanan
				pwm.x = -0.5*self.pwm_val1#kiri
			else:
				pwm.y = 0*self.pwm_val#belakang
				pwm.z = 0*self.pwm_val#kanan
				pwm.x = 0*self.pwm_val#kiri
		
		elif(self.analog[1] == -1):
			if(self.analog[0] == 1):
				pwm.y = 0*self.pwm_val#belakang
				pwm.z = -1*self.pwm_val#kanan
				pwm.x = 0.5*self.pwm_val#kiri
			elif(self.analog[0] == -1):
				pwm.y = 0*self.pwm_val#belakang
				pwm.z = -0.5*self.pwm_val#kanan
				pwm.x = self.pwm_val#kiri
			else:
				pwm.y = 0*self.pwm_val#belakang
				pwm.z = -1*self.pwm_val#kanan
				pwm.x = 1*self.pwm_val#kiri
		else:
			pwm.y = 0#belakang
			pwm.z = 0#kanan
			pwm.x = 0#kiri
		
		if(self.tb_start == 1):
			pos.x = 0
			pos.y = 0
			pos.z = 0	
			odom_pub.publish(pos)
			print "update position"
		
		if(self.button[0]==1):#A
			self.pwm_val = self.pwm_val - 5.
			print self.pwm_val
		elif(self.button[1]==1):#B
			self.pwm_val1 = self.pwm_val1 + 5.
			print self.pwm_val1
		if(self.button[2]==1):#X
			self.pwm_val1 = self.pwm_val1 - 5.
			print self.pwm_val1
		elif(self.button[3]==1):#Y
			self.pwm_val = self.pwm_val + 5.
			print self.pwm_val
		if(self.button[0] == 0) and (self.button[1] == 0) and (self.button[1] == 0) and (self.button[1] == 0) and (self.tb_start == 0):
			for i in range(0,10):
				pwm_pub.publish(pwm)
		
if __name__ == "__main__":
	rospy.init_node("robot2_joy_node")
	pwm_pub = rospy.Publisher("robot2/pwm_val", Vector3, queue_size=30)
	odom_pub = rospy.Publisher('/robot2/encoder_correction', Vector3, queue_size=3)
	pwm = Vector3()
	pos = Vector3()
	server = Server()
	print "Waiting For Data"
	try:
		rospy.Subscriber('/joy', Joy, server.read_joy)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass
