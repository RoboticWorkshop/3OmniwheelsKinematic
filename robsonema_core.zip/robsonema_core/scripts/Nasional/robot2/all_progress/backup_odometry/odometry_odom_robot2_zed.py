#!/usr/bin/env python

import math
from math import sin, cos, pi
import sympy as sp

import rospy
import tf
from numpy import *
from numpy.linalg import inv
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Point, Pose, Quaternion, Twist, Vector3

class Server:
	def __init__(self):
		self.position = sp.Matrix([[0., 0., 0.]]).transpose()
		self.current_time = rospy.Time.now()
		self.last_time = rospy.Time.now()
		
	def update_position(self, dat):
		quaternion = (
			dat.pose.pose.orientation.x,
			dat.pose.pose.orientation.y,
			dat.pose.pose.orientation.z,
			dat.pose.pose.orientation.w)
		
		#self.current_time = rospy.Time.now()
		euler = tf.transformations.euler_from_quaternion(quaternion)
		#roll = euler[0]
		#pitch = euler[1]
		x = dat.pose.pose.position.x
		y = dat.pose.pose.position.y
		z = dat.pose.pose.position.z
		yaw = euler[2]
		print "========================"
		print "x = ", x
		print "y = ", y
		print "z = ", z
		print "yaw = ", yaw*180./pi
		print "========================"
		#print quaternion
		
if __name__ == "__main__":
	rospy.init_node("zed_odom_subscriber_node")
	odom_broadcaster = tf.TransformBroadcaster()
	server = Server()
	try:
		rospy.Subscriber('/zed/odom', Odometry, server.update_position)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass
