#!/usr/bin/env python

import math
from math import sin, cos, pi
import sympy as sp

import rospy
import tf
from numpy import *
from numpy.linalg import inv
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Point, Pose, Quaternion, Twist, Vector3, PoseWithCovarianceStamped

class Server:
	def __init__(self):
		self.odom_th = 0.
		self.x = 0.
		self.y = 0.
		self.z = 0.
		self.w = 0.
		self.delay = rospy.Rate(10)
		self.counter = 0
	
	def get_pose(self, dat):
		self.odom_th = dat.z
	
	def get_odom(self, dat):
		self.x = dat.pose.pose.orientation.x
		self.y = dat.pose.pose.orientation.y
		self.z = dat.pose.pose.orientation.z
		self.w = dat.pose.pose.orientation.w
	
	def get_amcl(self, dat):
		new_amcl = dat
		new_amcl.header.stamp = rospy.Time.now()
		quaternion = (
			new_amcl.pose.pose.orientation.x,
			new_amcl.pose.pose.orientation.y,
			new_amcl.pose.pose.orientation.z,
			new_amcl.pose.pose.orientation.w)
		euler = tf.transformations.euler_from_quaternion(quaternion)
		amcl_th = euler[2]
		if(abs(amcl_th - self.odom_th)>(60.*pi/180.)):
			new_amcl.pose.pose.orientation.x = self.x
			new_amcl.pose.pose.orientation.y = self.y
			new_amcl.pose.pose.orientation.z = self.z
			new_amcl.pose.pose.orientation.w = self.w
			tmp = list(new_amcl.pose.covariance)
			#tmp[0] = 5.0
			#tmp[7] = 10.0
			new_amcl.pose.covariance = tuple(tmp)
			pub1.publish(new_amcl)
			self.counter = 0
			print "Publish Data1"
		if(self.counter > 200):
			new_amcl.pose.pose.orientation.x = self.x
			new_amcl.pose.pose.orientation.y = self.y
			new_amcl.pose.pose.orientation.z = self.z
			new_amcl.pose.pose.orientation.w = self.w
			pub1.publish(new_amcl)
			self.counter = 0
			print "Publish Data2"
		self.counter = self.counter + 1
		print self.counter, abs(amcl_th - self.odom_th)*180/pi
		
if __name__ == "__main__":
	rospy.init_node("robot2_pose_node")
	pub1 = rospy.Publisher("/robot2/initialpose", PoseWithCovarianceStamped, queue_size=10)
	new_amcl = PoseWithCovarianceStamped()
	server = Server()
	try:
		rospy.Subscriber('/robot2/odometry', Vector3, server.get_pose)
		rospy.Subscriber('/odom2', Odometry, server.get_odom)
		rospy.Subscriber('/robot2/amcl_pose', PoseWithCovarianceStamped, server.get_amcl)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass
