#!/usr/bin/env python

import math
from math import sin, cos, pi
import sympy as sp

import rospy
import tf
from numpy import *
from numpy.linalg import inv
from geometry_msgs.msg import Vector3
from std_msgs.msg import Int32

class Server:
	def __init__(self):
		self.robot1_ball = 0
		self.robot2_ball = 0
		self.cam_data = sp.Matrix([[0., 0., 0.]]).transpose()
		self.keeper_pos = sp.Matrix([[3., 0., 0.]]).transpose()
		
	def get_position(self, dat):
		self.cam_data[0,0] = dat.x
		self.cam_data[1,0] = dat.y
		self.cam_data[2,0] = dat.z
		self.main()
	
	def robot1_ball_position(self, dat):
		self.robot1_ball = dat.data
	
	def robot2_ball_position(self, dat):
		self.robot2_ball = dat.data
	
	def main(self):
		ball_pos = self.cam_data + self.keeper_pos
		print ball_pos
		
	
if __name__ == "__main__":
	rospy.init_node("odometry1_node")
	pub = rospy.Publisher("robot1/encoder_correction", Vector3, queue_size=1)
	odom = Vector3()
	server = Server()
	try:
		rospy.Subscriber('/robot1/camera', Vector3, server.get_position)
		rospy.Subscriber('/robot1/ball_position', Int32, server.robot1_ball_position)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass
