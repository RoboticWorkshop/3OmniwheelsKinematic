#!/usr/bin/env python

from __future__ import print_function

import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy
import numpy as np

from std_msgs.msg import Int32MultiArray
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import String

import sys, select, termios, tty

msg = """
Welcome to -- ROBSONEMA BASE STATION TELEOP KEY --
---------------------------
===== robot update node =====
q = Robot1 home cyan
Q = Robot1 home magenta
w = Robot2 home cyan
W = Robot2 home magenta
h = Robot1 central
H = Robot2 central
CTRL-C to quit
"""
#skill, position, info, goalkeeper command
moveBindingsRobot1 = {
		'q':(-6.45,4.,0.),
		'Q':(6.45,-4.,0.),
		'h':(0.,0.,0.),		
		}
moveBindingsRobot2 = {
		'w':(-6.45,-4.,0.),
		'W':(6.45,4.,0.),
		'H':(0.,0.,0.),		
		}

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)

	rospy.init_node('base_station_update_control')
	robot1_update = rospy.Publisher('robot1/encoder_correction', Float32MultiArray, queue_size = 2)
	robot2_update = rospy.Publisher('robot2/encoder_correction', Float32MultiArray, queue_size = 2)
	command = Float32MultiArray()
	note = String()
	command.data = [0,0,0]
	try:
		print(msg)
		while(1):
			key = getKey()
			if key in moveBindingsRobot1.keys():
				command.data[0] = moveBindingsRobot1[key][0]
				command.data[1] = moveBindingsRobot1[key][1]
				command.data[2] = moveBindingsRobot1[key][2]*np.pi/180.
				robot1_update.publish(command)
			elif key in moveBindingsRobot1.keys():
				command.data[0] = moveBindingsRobot2[key][0]
				command.data[1] = moveBindingsRobot2[key][1]
				command.data[2] = moveBindingsRobot2[key][2]
				robot2_update.publish(command)
			else:
				x = 0
				y = 0
				th = 0
				if (key == '\x03'):
					break
			print(command)
		
	except Exception as e:
		print(e)

	finally:
		x=0
		y=0
		#robot1_update.publish(command)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


