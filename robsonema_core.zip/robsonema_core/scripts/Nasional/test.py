#!/usr/bin/env python
import rospy
import numpy as np
from nav_msgs.msg import Odometry

def callback(dat):
	z = dat.pose.pose.orientation.z
	print z * 180./np.pi

if __name__ == "__main__":
	rospy.init_node("subs1_node")
	try:
		rospy.Subscriber("/odom1", Odometry, callback)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass
