#!/usr/bin/env python

import rospy
import random as rd
from numpy import *
from geometry_msgs.msg import Vector3
from std_msgs.msg import String
from std_msgs.msg import Int32
from std_msgs.msg import Float32
from std_msgs.msg import Int32MultiArray
from std_msgs.msg import Float32MultiArray

class Server:
	def __init__(self):
		#================================= Robot 1 Variable ====================================== (Start Sebelah kiri)
		self.robot1_des = array([[-0.8, 2., -90., -3.,  1., 0., "robot1 kick off"], #kickoff 0 (x1, y1, z1, x2, y2, z2)
									[-3.,  1., 0., -3.,  1., 0., "robot1 free kick"], #freekick 1
									[2.0,  1., 0., -4.5,  2.5, 45., "robot1 goal kick"], #goalkick 2									
									[-3.,  1., 0., -3.,  1., 0., "robot1 throw in"], #throwin 3
									[4.,  3., -20.,  -4,  2., 120., "robot1 corner kick"], #cornerkick 4
									[-3.,  1., 0., -3.,  3.5, 0., "robot1 penalty"], #penalty 5
									[-5.,  3.5, 0., -5., 3.5, 0., "robot1 Repair"], #Repair 6
									[-3,  1., 0., 0., 2., 90., "robot1 GOAL!!!"], #goal 7
									[-3.5,  3.5, 0., -3.5,  3.5, 0., "robot1 yellow card"], #Yellow 8
									[-3.5,  3.5, 0., -3.5,  3.5, 0., "robot1 red card"], #red 9
									[-3.,  2., 0., -3.,  2., 0.,"robot1 Drop Ball"]#drop ball 10
								]) #robot 1
		self.robot1_ball = 0 
		self.robot1_status = 0
		#================================= Robot 2 Variable ====================================== (Start Sebelah Kanan)
		self.robot2_des = array([[-0.7, -2., 90., -3., -1., 0., "robot2 kick off"], #kickoff 0 (x1, y1, z1, x2, y2, z2)
									[-3., -1., 0., -3., -1., 0., "robot2 free kick"], #freekick 1
									[2.0, -1., 0., -4.5, -2.5, 45., "robot2 goal kick"], #goalkick 2									
									[-3., -1., 0., -3., -1., 0., "robot2 throw in"], #throwin 3
									[4., -3., -20., -4, -2., -120., "robot2 corner kick"], #cornerkick 4
									[-3., -1., 0., -3., -3.5, 0., "robot2 penalty"], #penalty 5
									[-5., -3.5, 0., -5., -3.5, 0., "robot2 Repair"], #Repair 6
									[-3, -1., 0., 0., -2., 90., "robot2 GOAL!!!"], #goal 7
									[-3.5, -3.5, 0., -3.5, -3.5, 0., "robot2 yellow card"], #Yellow 8
									[-3.5, -3.5, 0., -3.5, -3.5, 0., "robot2 red card"], #red 9
									[-3., -2., 0., -3., -2., 0.,"robot2 Drop Ball"]#drop ball 10
								]) #robot 2
		self.robot2_ball = 0 
		self.robot2_status = 0
		#================================= Global Variable ====================================
		self.cmd = array([[0, 1]])
		self.lottery = [1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0]
		self.strategy = 0
		print "node manager running"

	#def odometry_fw(self, dat):#subscribe odometry robot 1
	#	self.odom[0,0] = dat.x
	#	self.odom[0,1] = dat.y
	#	self.odom[0,2] = dat.z
		#self.command_skill_robot1()

	#def odometry_cb(self, dat):#subscribe odometry robot 2
	#	self.odom[1,0] = dat.x
	#	self.odom[1,1] = dat.y
	#	self.odom[1,2] = dat.z		
		#self.command_skill_robot2()

	def get_ball_position1(self, dat):	#subscribe posisi bola robot1
		self.robot1_ball = dat.data
		self.command_skill_robot1()

	def get_ball_position2(self, dat):	#subscribe posisi bola robot2
		self.robot2_ball = dat.data
		self.command_skill_robot2()

	def command_input(self, dat):		#Subscribe Data Perintah dari Ref_Box
		self.positioning = dat.data[0]	#mode gerakan, 0 = stop, 1 = Kejar Bola, 2 = Positioning
		self.cmd[0,0] = dat.data[1]		#kode gerakan yang akan dilakukan (Kick Off, Goal Kick, Corner Kick, Drop Ball)
		self.cmd[0,1] = dat.data[2]		#kode posisi menyerang atau posisi bertahan
		#if(self.positioning == 1):
		#	robot1_dribbler_pub.publish(1)
		#	robot2_dribbler_pub.publish(1)
		#else:
		#	robot1_dribbler_pub.publish(0)
		#	robot2_dribbler_pub.publish(0)
		self.strategy = self.lottery[rd.randint(0,9)]
		if(self.strategy == 0):
			robot1_status.publish(1)		
			robot2_status.publish(0)
			print "ROBOT1 GET BALL"
		else:
			robot1_status.publish(0)		
			robot2_status.publish(1)
			print "ROBOT2 GET BALL"
		self.command_skill_robot1()
		self.command_skill_robot2()
		#print self.positioning	
	
	def command_skill_robot1(self):#publish skill
		robot1_data.data[0] = self.positioning
		robot1_data.data[4] = self.cmd[0,1]
		if(self.positioning == 0):
			self.robot1_status = 0
			print "Robot1 Stop"

		if(self.positioning == 1): #game on / start
			print "Robot1 Start Playing"

		elif(self.positioning == 2): #positioning
			if(self.cmd[0,1]==0):
				robot1_data.data[1] = float(self.robot1_des[self.cmd[0,0], 0])
				robot1_data.data[2] = float(self.robot1_des[self.cmd[0,0], 1])
				theta1 = float(self.robot1_des[self.cmd[0,0], 2])*pi/180.
				robot1_data.data[3] = theta1
			if(self.cmd[0,1]==1):
				robot1_data.data[1] = float(self.robot1_des[self.cmd[0,0], 3])
				robot1_data.data[2] = float(self.robot1_des[self.cmd[0,0], 4])
				theta1 = float(self.robot1_des[self.cmd[0,0], 5])*pi/180.
				robot1_data.data[3] = theta1
			print(self.robot1_des[self.cmd[0,0], 6])
		robot1_pub.publish(robot1_data)
	
	def command_skill_robot2(self):#publish skill
		robot2_data.data[0] = self.positioning
		if(self.positioning == 0):
			self.robot2_status = 0
			print "Robot2 Stop"

		if(self.positioning == 1): #game on / start
			print "Robot2 Start Playing"

		elif(self.positioning == 2): #positioning
			if(self.cmd[0,1]==0):
				robot2_data.data[1] = float(self.robot2_des[self.cmd[0,0], 0])
				robot2_data.data[2] = float(self.robot2_des[self.cmd[0,0], 1])
				theta2 = float(self.robot2_des[self.cmd[0,0], 2])*pi/180.
				robot2_data.data[3] = theta2
			if(self.cmd[0,1]==1):
				robot2_data.data[1] = float(self.robot2_des[self.cmd[0,0], 3])
				robot2_data.data[2] = float(self.robot2_des[self.cmd[0,0], 4])
				theta2 = float(self.robot2_des[self.cmd[0,0], 5])*pi/180.
				robot2_data.data[3] = theta2
			print(self.robot2_des[self.cmd[0,0], 6])
		robot2_pub.publish(robot2_data)
			
if __name__ == "__main__":
	rospy.init_node('robsonema_team_manager_node')
	robot1_pub = rospy.Publisher('robot1/skill', Float32MultiArray, queue_size = 2)
	robot1_dribbler_pub = rospy.Publisher('robot1/dribbler', Int32, queue_size = 1)
	robot1_data = Float32MultiArray()
	robot2_pub = rospy.Publisher('robot2/skill', Float32MultiArray, queue_size = 2)
	robot2_dribbler_pub = rospy.Publisher('robot2/dribbler', Int32, queue_size = 1)
	robot2_data = Float32MultiArray()
	strat = rospy.Publisher('node_manager/strategy', Int32, queue_size = 1)
	server = Server()
	robot1_data.data = [0,0,0,0,0]
	robot2_data.data = [0,0,0,0,0]
	try:
		#====================  from robot 1  =======================================
		rospy.Subscriber('robot1/odometry', Vector3, server.odometry_cb)
		rospy.Subscriber('robot1/ball_position', Int32, server.get_ball_position2)
		#rospy.Subscriber('/robot2/command_clear', Int32, server.get_clear)
		#====================  from robot 2  =======================================
		rospy.Subscriber('robot2/odometry', Vector3, server.odometry_cb)
		rospy.Subscriber('robot2/ball_position', Int32, server.get_ball_position2)
		#rospy.Subscriber('/robot2/command_clear', Int32, server.get_clear)
		# =================== from reff box node ===================================
		rospy.Subscriber('base_station_command', Int32MultiArray, server.command_input)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass
