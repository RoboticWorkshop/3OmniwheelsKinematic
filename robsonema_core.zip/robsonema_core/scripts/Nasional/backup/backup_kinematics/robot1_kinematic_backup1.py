#!/usr/bin/env python
#kinematic control robot1
import sympy as sp
import numpy as np
from numpy import *
import matplotlib.pyplot as plt
from numpy.linalg import inv
import rospy
import random as rd
from geometry_msgs.msg import Vector3
from std_msgs.msg import Float32
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import Int32


class Server:
	def __init__(self):
		#==================================================================================================
		#variabel kinematik
		self.alp = array([[0*pi/180, 120*pi/180, 240*pi/180]]).T #robot specification
		self.cam_des = sp.Matrix([[160., 90*pi*180, -70.]]).transpose() #tujuan posisi bola di kamera
		self.cam = sp.Matrix([[0., 0., 0.]]).transpose() #posisi aktual bola di kamera
		self.omni_cam = sp.Matrix([[0., 0., 0.]]).transpose()
		self.cam_rot = sp.Matrix([[1,0,0], [0,0,1], [0,0,0]]) #rotasi matrix untuk camera ke robot
		self.l = 0.20 #panjang posisi roda robot dari titik tengah robot
		self.r = 0.05 #besar jari - jari roda robot
		self.Jr = self.jacobianR()
		self.th = 0. * pi / 180. #nilai heading awal robot
		self.x_des = sp.Matrix([[0., 0., 0.]]).transpose()#koordinat tujuan (dari node manager)
		self.x = sp.Matrix([[0, 0, 0]]).transpose()#koordinat aktual
		self.lamda = sp.Matrix([[17., 0., 0.], [0., 17.., 0.], [0., 0., 25.]])
		#self.lamda = array([[20, 20]])
		#=======================================================================================
		#variabel visual servoing
		self.kp1 = 0.85 #0.85 
		self.kp2 = 8.0 # 1.75
		self.kp3 = 5.
		self.v_lambda = sp.Matrix([[self.kp1 , 0., 0.], [0., self.kp2, 0.], [0., 0., self.kp3]])
		self.iLs = self.camera_matrix()
		self.lastcm = 0 #
		#=========================================================================================
		#variabel lainnya
		self.skill = 0 #mode yang dikirimkan oleh node manager (0:stop, 1:visual servoing, 2: positioning)
		self.ball = 0 #index bola
		self.ball1 = 0 #index bola di robot teman
		self.detik = 0 #waktu untuk akselerasi
		self.kick = 0
		self.diff = 0
		self.lastdiff = 0
		self.index_complete = 0
		self.index_lock_complete = 0
		
	def jacobianR(self): #jacobian robot
		Js=array([[0.,0.,0.],[0.,0.,0.],[0.,0.,0.]])
		Js[0,0]=sp.cos(self.alp[0,0])
		Js[0,1]=sp.cos(self.alp[1,0])
		Js[0,2]=sp.cos(self.alp[2,0])
		Js[1,0]=sp.sin(self.alp[0,0])
		Js[1,1]=sp.sin(self.alp[1,0])
		Js[1,2]=sp.sin(self.alp[2,0])
		Js[2,0]=1./self.l
		Js[2,1]=1./self.l
		Js[2,2]=1./self.l
		#print(Jr)
		return self.r*Js
	
	def jacobianW(self,th,Jr): #jacobian robot terhadap lapangan
		rotZ = array([[sp.cos(th), -sp.sin(th), 0.], [sp.sin(th), sp.cos(th), 0.], [0., 0., 1]])
		Jw = rotZ.dot(Jr)
		return sp.Matrix(Jw)
		
	def camera_matrix(self):
		Ls = sp.Matrix([[0,0,0],[0,0,0],[0,0,0]])
		Ls[0,0] = -1. / 0.33
		Ls[0,1] = 0
		Ls[0,2] = 160. / 0.35
		Ls[1,0] = 0
		Ls[1,1] = -1./ 0.33
		Ls[1,2] = 175./0.33
		Ls[2,0] = 0
		Ls[2,1] = 0
		Ls[2,2] = 74. * (2. / 0.33)
		Lsinv = Ls.inv()
		return Lsinv

	def get_odom(self, dat):
		self.x[0, 0] = dat.x #present x coordinate
		self.x[1, 0] = dat.y #present y coordinate
		self.x[2, 0] = dat.z #present heading in radian
		self.th = self.x[2, 0]
		self.main()

	def get_skill(self, dat):
		self.skill = dat.data[0] #mode gerakan
		self.x_des[0, 0] = dat.data[1] #x tujuan
		self.x_des[1, 0] = dat.data[2] #y tujuan
		self.x_des[2, 0] = dat.data[3] #theta tujuan
		self.index_serang = dat.data[4] #posisi defend atau attack
		if(self.index_serang == 0):
			self.kick = 0
		else:
			self.kick = 1
		self.index_lock_complete = 0
		
	def get_camera(self, dat):#subscribe data bola dari kamera
		self.cam[0,0] = dat.x
		self.cam[1,0] = dat.y
		self.cam[2,0] = -dat.z
		#self.main()

	def get_ball_info(self, dat):#subscribe posisi bola
		self.ball = dat.data
	
	def get_ball_info2(self, dat):#subscribe posisi bola
		self.ball1 = dat.data

	def pwm_leveling(self, w):
		#====================== W1 ====================
		if(w[0,0]>0.4) and (w[0,0]<100):
			w[0,0] = 100
		elif (w[0,0]<-0.4) and (w[0,0]>-100):
			w[0,0] = -100
		elif(w[0,0]>400):
			w[0,0] = 400
		elif (w[0,0]<-400):
			w[0,0] = -400
		#====================== W2 ====================
		if(w[1,0]>0.4) and (w[1,0]<100):
			w[1,0] = 100
		elif (w[1,0]<-0.4) and (w[1,0]>-100):
			w[1,0] = -100
		elif(w[1,0]>400):
			w[1,0] = 400
		elif (w[1,0]<-400):
			w[1,0] = -400
		#====================== W3 ====================
		if(w[2,0]>0.4) and (w[2,0]<100):
			w[2,0] = 100
		elif (w[2,0]<-0.4) and (w[2,0]>-100):
			w[2,0] = -100
		elif(w[2,0]>400):
			w[2,0] = 400
		elif (w[2,0]<-400):
			w[2,0] = -400
		pwm.y = w[0,0] #belakang
		pwm.z = w[1,0] #kanan
		pwm.x = w[2,0] #kiri
		pwm_pub.publish(pwm)
		#print(pwm)
		
	def pwm_leveling1(self, w):
		#====================== W1 ====================
		if(w[0,0]>0.4) and (w[0,0]<100):
			w[0,0] = 100
		elif (w[0,0]<-0.4) and (w[0,0]>-100):
			w[0,0] = -100
		if(w[0,0]>400):
			w[0,0] = 400
		elif (w[0,0]<-400):
			w[0,0] = -400
		#====================== W2 ====================
		if(w[1,0]>0.4) and (w[1,0]<100):
			w[1,0] = 100
		elif (w[1,0]<-0.4) and (w[1,0]>-100):
			w[1,0] = -100
		if(w[1,0]>400):
			w[1,0] = 400
		elif (w[1,0]<-400):
			w[1,0] = -400
		#====================== W3 ====================
		if(w[2,0]>0.4) and (w[2,0]<100):
			w[2,0] = 100
		elif (w[2,0]<-0.4) and (w[2,0]>-100):
			w[2,0] = -100
		if(w[2,0]>400):
			w[2,0] = 400
		elif (w[2,0]<-400):
			w[2,0] = -400
		pwm.y = w[0,0]
		pwm.z = w[1,0]
		pwm.x = w[2,0]
		pwm_pub.publish(pwm)
		
	def visual_servoing(self):#fungsi gerakan mendekati bola
		J = self.jacobianW(self.th, self.Jr)#hitung jacobian
		vJinv = sp.Matrix(self.Jr).inv()#invers jacobian
		self.Jinv = J.inv()
		er = self.cam_des - self.cam #hitung error
		rr = self.cam_rot * er #rotasikan hasil error kamera ke frame posisi robot
		rr[2,0] = self.cam[1,0] - (90.*pi/180.) #heading ball
		#============================================================
		#set nilai kp saat visual servoing
		if(self.cam[2,0] >= -20):#jika bola jauh
			if(self.cam[0,0]>30) and (self.cam[0,0]<280):
				self.v_lambda[0,0] = 2.8  #2.5
				self.v_lambda[1,1] = 2.75 #2.75
				self.v_lambda[2,2] = 5.0
			else:
				self.v_lambda[0,0] = 1.0#0.75
				self.v_lambda[1,1] = 1.5
				self.v_lambda[2,2] = 6
		elif(self.cam[2,0] >= -40):#jika posisi bola sudah dekat
			self.v_lambda[0,0] = 0.75
			self.v_lambda[1,1] = 1.5
			self.v_lambda[2,2] = 4
		else:
			self.v_lambda[0,0] = 0.6
			self.v_lambda[1,1] = 1.4
			self.v_lambda[2,2] = 7.
		#=====================================================
		#algoritma pergerakan mengejar bola
		if((self.cam[1,0] - self.lastcm) < 0):
			self.diff = 2
		elif((self.cam[1,0] - self.lastcm) > 0):
			self.diff = -2
		
		if(self.lastdiff != self.diff):
			self.detik=0
			self.lastdiff = self.diff
			
		if(self.cam[1,0] > 2.15) and (self.cam[1,0] < 2.16):#jika bola tidak terlihat di kamera
			w = vJinv * (self.v_lambda * self.iLs * rr)
			if(self.diff<0):
				w[0,0] = -30
				w[1,0] = -30
				w[2,0] = -30
			else:
				w[0,0] = 30
				w[1,0] = 30
				w[2,0] = 30
			w = w * self.v_lambda[2,2]
		elif(rr.norm()<15):#jika robot sudah dekat dengan bola sesuai dengan tujuan yang diinginkan
			rr[0, 0] = rr[0,0] * 0
			rr[1, 0] = rr[1,0] * 0
			rr[2, 0] = rr[2,0] * 0
			w = vJinv * (self.v_lambda * self.iLs * rr)
		else:
			w = vJinv * (self.v_lambda * self.iLs * rr)
		self.lastcm = self.cam[1,0]
		self.pwm_leveling1(w)	

	def ball_chaser(self):#gerakan mengambil bola
		w = sp.Matrix([[0,0,0]]).transpose()
		if(self.cam[0,0] > 100) and (self.cam[0,0] < 220):
			w[0,0] = 0#w1 belakang
			w[1,0] = 300#w2 kanan
			w[2,0] = -300#w3 kiri
		elif(self.cam[0,0] > 0) and (self.cam[0,0] <= 100):
			w[0,0] = 0#w1 belakang
			w[1,0] = 120#w2 kanan
			w[2,0] = 120#w3 kiri
		elif(self.cam[0,0] > 220):
			w[0,0] = 0#w1 belakang
			w[1,0] = -120#w2 kanan
			w[2,0] = -120#w3 kiri
		self.pwm_leveling(w)	
		
	def control(self):#fungsi untuk positioning
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#==================== compute error ==================================
		self.Er = self.x_des - self.x
		if(self.Er.norm()<0.05):
			self.Er = self.Er * 0.
			self.detik = 0
			self.index_complete = 1
			if(self.index_lock_complete == 0):
				complete_pub.publish(self.index_complete)
				self.index_lock_complete = 1
		else:
			self.index_complete = 0
			self.detik = self.detik + 1
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*self.Er
		print self.Er.norm()
		#print self.detik
		self.pwm_leveling(w)	

	def go_to_target(self):
		J = self.jacobianW(self.th, self.Jr)
		self.Jinv = J.inv()
		#==================== compute error ==================================
		self.Er = self.x_des - self.x
		if(self.Er.norm()<0.05):
			self.Er = self.Er * 0.
			self.detik = 0
			tendang.data = 1
			kicker_pub.publish(tendang)
		else:
			self.detik = self.detik + 1
		#===================== compute w for motor ============================
		w = self.kp*self.Jinv*self.Er
		self.pwm_leveling(w)		
	
	def main(self):
		#print self.skill
		if(self.skill == 0):#command stop
			pwm.y = 0
			pwm.z = 0
			pwm.x = 0
			pwm_pub.publish(pwm)
			print "ROBOT STOP"

		elif(self.skill == 1):#command ball_finder
			#=========akselerasi================
			if(self.detik < 30):
				self.kp = self.lamda[0,0]*0.5
			elif(self.detik < 50):
				self.kp = self.lamda[0,0]*0.75
			else:
				self.kp = self.lamda[0,0]
			#===================================
			if(self.ball == 1):#game start
				if(self.kick == 0):
					tendang.data = 2
					kicker_pub.publish(tendang)
					self.kick =1
				else:
					self.go_to_target()
					#print "GO TO TARGET"
			elif(self.ball1 == 1):
				self.kick = 1
				self.control()
				#print "GO FIND POSITION"
			elif(self.cam[2,0] > -55):#jika bola masih jauh melakukan visual servoing
				self.visual_servoing()
				#print "VISUAL SERVOING"
			elif(self.cam[2,0] <=-55):
				self.ball_chaser()#jika bola sudah dekat melakukan gerakan maju
				#print "BALL CHASER"
						
		elif(self.skill == 2):#command position
			if(self.detik < 30):
				self.kp = self.lamda*0.5
			elif(self.detik < 50):
				self.kp = self.lamda*0.75
			else:
				self.kp = self.lamda
			self.control()
			#print "ROBOT POSITIONING"
	
if __name__ == "__main__":
	rospy.init_node("robot1_kinematic_node")
	pwm_pub = rospy.Publisher("robot1/pwm_val", Vector3, queue_size=2)
	kicker_pub = rospy.Publisher("robot1/kick_ball", Int32, queue_size=1)
	complete_pub = rospy.Publisher("robot1/command_clear", Int32, queue_size=1)
	pwm = Vector3()
	server = Server()
	try:
		rospy.Subscriber('robot1/skill', Float32MultiArray, server.get_skill)#perintah yang masuk dari node manager
		rospy.Subscriber('robot1/odometry', Vector3, server.get_odom)
		rospy.Subscriber('robot1/camera', Vector3, server.get_camera)
		rospy.Subscriber('robot1/ball_position', Int32, server.get_ball_info)
		rospy.Subscriber('robot2/ball_position', Int32, server.get_ball_info2)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass
