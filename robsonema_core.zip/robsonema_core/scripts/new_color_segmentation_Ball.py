#!/usr/bin/env python
from __future__ import print_function

import roslib
import numpy as np
from numpy import linalg as LA
#roslib.load_manifest('my_package')
import sys
import rospy
import cv2
from std_msgs.msg import String
from geometry_msgs.msg import Vector3
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from matplotlib.colors import hsv_to_rgb
from imutils.video import VideoStream
import imutils

class image_converter:

  def __init__(self):
  	self.bridge = CvBridge()
    self.image_sub = rospy.Subscriber("/cv_camera/image_raw",Image,self.callback)
    #self.lowerBound=np.array([0,125,188])
    #self.upperBound=np.array([25,255,255])
    self.lowerBound=np.array([0,162,227])
    self.upperBound=np.array([47,255,255])
    self.mask = cv2.imread('mask.png',0)
    self.cam_center = np.array([302, 234])
    self.coeff1 = np.array([-6.420863187e-01 ,1.366883294e-02, -2.145237355e-05])
    self.coeff2 = np.array([12.51559145, -4.950694193e-01, 7.035878859e-03, -4.208641136e-05, 9.236918414e-08])
    self.u = np.array([0, 132])
    self.rot = np.array([[np.cos(90.*np.pi/180.), -np.sin(90.*np.pi/180.)], [np.sin(90.*np.pi/180.), np.cos(90.*np.pi/180.)]])
    self.pub = rospy.Publisher("/robot1/camera", Vector3, queue_size = 10)
    self.cam_data = Vector3()

  def callback(self,data):
    try:
      cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
    except CvBridgeError as e:
      print(e)
    cv_image = cv2.bitwise_and(cv_image,cv_image,mask = self.mask)
    blurr=cv2.GaussianBlur(cv_image,(11,11),0)
    imgHSV= cv2.cvtColor(blurr,cv2.COLOR_BGR2HSV)
    mask=cv2.inRange(imgHSV, self.lowerBound, self.upperBound)
    mask=cv2.erode(mask,None,iterations=1)
    mask=cv2.dilate(mask,None,iterations=1)
    conts=cv2.findContours(mask.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    conts=imutils.grab_contours(conts)
    for i in range(len(conts)):
      (x,y),radius = cv2.minEnclosingCircle(conts[i])
      center = (int(x),int(y))
      radius = int(radius)
      bola = cv2.circle(cv_image,center,radius,(0,200,10),2) 
      M = cv2.moments(conts[i])
      x = int(M['m10']/M['m00'])
      y = int(M['m01']/M['m00'])
      v = np.array([self.cam_center[0]-x, self.cam_center[1]-y])
      num = np.dot(self.u, v)
      den = LA.norm(self.u)*LA.norm(v)
      th = np.arccos(num/den)
      if(x < self.cam_center[0]):
        th = -1*th
      ri = (self.cam_center[0] - x)**2 + (self.cam_center[1] - y)**2
      ri = np.sqrt(ri)
      if(ri < 122.4949):
      	rx = self.coeff1[0] + self.coeff1[1]*ri + self.coeff1[2]*(ri**2) + 0.23
      else:
      	rx = self.coeff2[0] + self.coeff2[1]*ri + self.coeff2[2]*(ri**2) + self.coeff2[3]*(ri**3) + self.coeff2[4]*(ri**4) + 0.23
      #print(rx, th*180./np.pi)
      x_pos = np.array([[rx*np.cos(th), rx*np.sin(th)]]).T
      x_pos = np.dot(self.rot, x_pos)
      self.cam_data.x = x_pos[0]
      self.cam_data.y = x_pos[1]
      self.cam_data.z = th
      self.pub.publish(self.cam_data)
      #print(x_pos[0], x_pos[1])
    #cv2.imshow("cv_image", cv_image)
    #cv2.waitKey(3)

def main(args):
  ic = image_converter()
  rospy.init_node('image_converter', anonymous=True)
  try:
    rospy.spin()
  except KeyboardInterrupt:
    print("Shutting down")
  cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)
